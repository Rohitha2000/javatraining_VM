# kafka-consumer
Apache Kafka Consumer Example using SpringBoot
