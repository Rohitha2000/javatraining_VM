package IncrementCalculate;

import java.util.*;

public class IncrementCalculation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sal;
		double rate;
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the salary: ");
		sal = s.nextInt();
		System.out.println("Enter the Performance appraisal rating");
		rate = s.nextDouble();
		if(sal==0 || sal<0 || rate<1 || rate>5)
		{
			System.out.println("Invalid Input");
		}
		
		else
		{
			double cen, per;
//			 cen = 80.0;
//			   per= (double) cen/100.0;
//			   System.out.println(per);
			if(rate>=1 && rate<=3)
			{
				cen= 10.0;
				per= (double) cen/100.0;
				double t= sal* per;
				
				System.out.println(sal+t);
			}
			else if(rate>= 3.1 && rate <=4)
			{
				cen= 25.0;
				per= (double) cen/100.0;
				double t= sal* per;
				
				System.out.println(sal+t);
			}
			else if(rate>= 4.1 && rate<=5)
			{
				cen= 30.0;
				per= (double) cen/100.0;
				double t= sal* per;
				
				System.out.println(sal+t);
			}
		}
	}

}
