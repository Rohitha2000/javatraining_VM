package Stringrotate;
import java.util.*;
public class StringRotate {
    public static boolean rotate(String a, String b)
    {
    	int len1= a.length();
    	int len2= b.length();
    	if(len1 != len2)
    	{
    		System.out.println("String is not a rotation of another");
    		return false;
    	}
    	else
    	{
    		String str3= a+a;
    		if(str3.contains(b))
    		{
    			System.out.println("String is rotation of another");
    			return true;
    		}
    		else
    		{
    			System.out.println("String is not a rotation of another");
    			return false;
    		}
    	}
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s= new Scanner(System.in);
		System.out.println("Enter string 1");
		String s1= s.next();
		System.out.println("Enter string 2");
		String s2= s.next();
        rotate(s1, s2);
	}

}
