package VowelCount;

import java.util.*;

public class vowelstringcount {
	public static void main(String args[]) {
		
		System.out.println("Enter a sentence :");
		
		for (int j = 0; j >= 0; j++) 
		{
			int count = 0;
			String qt = "quit";
			Scanner sc = new Scanner(System.in);
			String sentence = sc.nextLine();
			if (sentence.equals(qt)) 
			{
				System.exit(0);
			} else {
				for (int i = 0; i < sentence.length(); i++) 
				{
					char ch = sentence.charAt(i);
					if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u'|| ch == 'A'|| ch == 'E'|| ch == 'I'|| ch == 'O'|| ch == 'U') {
						count++;
					}
				}
				System.out.println("Number of vowels in the given sentence is " + count);
			}
		}
	}
}