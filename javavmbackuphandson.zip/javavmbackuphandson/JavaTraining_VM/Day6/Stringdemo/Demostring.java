package Stringdemo;

public class Demostring {
	public static void main(String[] args) {
		String s = "Hello" + "String";
		System.out.println("concat----" + s);
		StringBuilder str = new StringBuilder(s);
		str.append("How are you").append(1234567);
		System.out.println("append---" + str);
		s = s.concat("Buffer");
		System.out.println("concat method---" +s);

	}

}
