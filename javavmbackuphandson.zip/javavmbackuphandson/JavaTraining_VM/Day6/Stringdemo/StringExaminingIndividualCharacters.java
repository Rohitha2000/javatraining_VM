package Stringdemo;

public class StringExaminingIndividualCharacters {
	static void stringExamples() {
		System.out.println("\nInside stringExamples ...");
		String s = "hello world!";
		System.out.println("s: " + s);

		// Examining individual characters
		System.out.println("\ns.charAt(4): " + s.charAt(0));
	}

	public static void main(String[] args) {

		StringExaminingIndividualCharacters.stringExamples();
	}

}
