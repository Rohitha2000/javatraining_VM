package Stringdemo;

public class StringConcat {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "Hello" + "World";
		String s1 = "good" + "morning";
		//StringBuilder sh = new StringBuilder();
		StringBuffer sh = new StringBuffer();
		sh.append("Dear").append("Guys");

		System.out.println("This is concatination\n" + s1);
		System.out.println("StringBuffer\n" + sh);
		System.out.println("object using tostrings\n" + sh.toString());
		System.out.println("Find length :" +sh.length());
		System.out.println("other functions" +s1.hashCode());
		sh.deleteCharAt(1);//DearGuys
		sh.deleteCharAt(3);//DarGuys
		System.out.println("deleting---" +sh.toString());
		System.out.println("Find length :" +sh.length());
		System.out.println("object using tostrings\n" + sh.toString());
		sh.insert(2, "ow");//DGuys -- DGowuys
		System.out.println("Find length :" +sh.length());
		System.out.println("object using tostrings\n" + sh.toString());

	}

}
