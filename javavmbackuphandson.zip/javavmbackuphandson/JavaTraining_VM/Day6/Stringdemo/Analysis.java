package Stringdemo;

public class Analysis {
	public static void main(String[] args) {
		
		String str= "rohitha";
	//	s.concat("gour");   strings are immutable
		
		String str1= "ROHITHA";
		// comparing strings
		System.out.println("String equals method");
		if(str1.equals(str))
		{
			System.out.println("true");
		}
		else {
			System.out.println("false");
		}
		
		System.out.println("equals ignore case");
		if( str1.equalsIgnoreCase(str))
		{
			System.out.println("true");
		}
		else
		{
			System.out.println("false");
		}
		
		System.out.println("compareTo --  "+str1.compareTo(str));
		
		// concatenation
		str= str.concat("lit");
		System.out.println("After concat string-   "+str);
		
		// split
		String[] words= str.split("i");
		System.out.println("Strings after splitting ");
		for(String sr: words)
			System.out.println(sr);
		
		// String Buffer
		System.out.println("/n String Buffer /n");
		StringBuffer s= new StringBuffer("Hello people");
		s.append(" morning");
		System.out.println(s);
		s.delete(1,2);
		System.out.println("after delete--  "+s);
		s.replace(4, 7,"roh");
		System.out.println("after replace--  "+s);
		s.reverse();
		System.out.println("After reverse-  "+s);
		
		
		//String Builder
		System.out.println("/n String Builder /n");
		StringBuilder sh = new StringBuilder("Hello guys");
		sh.append("gals").append("boys");
		System.out.println("string buffer----" +sh.toString());
		System.out.println("reverse  " +sh.reverse());
		System.out.println("Replacing "+s.replace(3, 7, "rohi"));
		
	}
}
