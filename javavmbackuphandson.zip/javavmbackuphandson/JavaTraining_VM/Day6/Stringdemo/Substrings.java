package Stringdemo;

public class Substrings {

	static void stringExamples() {
		System.out.println("\nInside stringExamples ...");
		String s = "hello world!";
		System.out.println("s: " + s);
		// Extracting substrings
		System.out.println("\ns.substring(4): " + s.substring(4));//hello world!
		System.out.println("s.substring(4, 9): " + s.substring(4, 9));
		System.out.println("charat--" +s.charAt(5));
		
	}

	public static void main(String[] args) {

		Substrings.stringExamples();
	}

}
