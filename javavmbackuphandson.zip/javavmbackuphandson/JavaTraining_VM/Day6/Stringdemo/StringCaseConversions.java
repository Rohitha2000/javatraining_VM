package Stringdemo;

import java.util.*;

public class StringCaseConversions {
	static void stringExamples() {
		System.out.println("\nInside stringExamples ...");
		String s = "   hello world!  ";
		System.out.println("s: " + s);

		// Case conversions (Note: String is immutable. So, only a copy is returned)
		System.out.println("\ns.toUpperCase(): " + s.toUpperCase());
		System.out.println("s.toLowerCase(): " + s.toLowerCase());
		System.out.println("\ns.trim(): " + s.trim()); // returns a copy of string after trimming any leading & trailing
		// white spaces

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		stringExamples();
	}

}
