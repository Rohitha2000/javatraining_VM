package Stringdemo;

public class Length {
	static void stringExamples() {
		System.out.println("\nInside stringExamples ...");
		String s = "hello world!";
		String s1 = "";
		System.out.println("s: " + s);

		System.out.println("\ns.length(): " + s.length());
		System.out.println("s.isEmpty(): " + s1.isEmpty());

	}

	public static void main(String[] args) {
	   Length.stringExamples();
	}

}
