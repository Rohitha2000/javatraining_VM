package Stringdemo;

public class Stringexamples {

	public static void main(String[] args) {
		
		

		System.out.println("Sample String Input...");
		String s1 = "Hi string literals";
		// String s2 = "Hi string literals";
		char[] ch = { 'g', 'e', 't' };
		
		  String s3 = new String(ch);
		  String s4 = new String("geetha");
		  System.out.println(s1); System.out.println(s3); System.out.println(s4);
		 System.out.println(ch.equals(s3));
		 
		
	}

}
