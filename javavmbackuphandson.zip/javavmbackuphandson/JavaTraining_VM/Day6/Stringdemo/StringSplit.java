package Stringdemo;

public class StringSplit {
	static void stringExamples() {
		System.out.println("\nInside stringExamples ...");
		String s = "hello world!";
		System.out.println("s: " + s);

		// Split (e.g., split a document into words or split a line of text by tab or
		// comma or white space)
		System.out.println("\ns.split(\"o\"): ");

		String[] sa = s.split("o");
		for (String temp : sa) {
			System.out.println(temp);
		}
	}

	void math() {
		System.out.println("this is non static");
	}

	

	public static void main(String[] args) {
		StringSplit.stringExamples();
		StringSplit obj = new StringSplit();
		obj.math();

	}


}
