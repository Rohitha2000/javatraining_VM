package BankAccount;
import java.util.*;
public class AccountDetails extends Account {
	public static Account getAccountDetails() 
	{
		String account;
		int id, bal;
		Account a= new Account();
		Scanner s= new Scanner(System.in);
		System.out.println("Enter account id");
		id= s.nextInt();
		a.setAccountid(id);
		System.out.println("Enter Account type");
		account= s.next();
		a.setAccounttype(account);
		System.out.println("Enter balance");
	    bal= s.nextInt();
	    
	    a.setBalance(bal);
	    System.out.println("balace:  "+ a.getBalance());
		while(bal<=0)
		{
	       	System.out.println("Enter balance");
		    bal= s.nextInt();
		    a.setBalance(bal);
		    if(bal<=0)
		    	System.out.println("balance should be positive");
		}
		
		return a;
	}
	public static int getWithdrawAmount() 
	{
		Scanner s= new Scanner(System.in);
		System.out.println("Enter amount to be withdrawn");
		int wit= s.nextInt();
		//System.out.println("wit:   "+wit);
		while(wit<= 0)
		{
			System.out.println("Enter amount to be withdrawn");
			 wit= s.nextInt();
			 if(wit<=0)
			    	System.out.println("withdrawl amount should be positive");
		}
		return wit;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Account ae= new Account();
		Account a= getAccountDetails();
		int amt= getWithdrawAmount();
		ae.withdraw(amt, a);

	}

}
