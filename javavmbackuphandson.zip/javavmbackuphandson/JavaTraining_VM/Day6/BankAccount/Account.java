package BankAccount;

public class Account {
private int accountid;
private int balance;
private String accounttype;

public int getAccountid() {
	return accountid;
}

public void setAccountid(int accountid) {
	this.accountid = accountid;
}

public int getBalance() {
	return balance;
}

public void setBalance(int balance) {
	this.balance = balance;
}

public String getAccounttype() {
	return accounttype;
}

public void setAccounttype(String accounttype) {
	this.accounttype = accounttype;
}

public boolean withdraw(int amt, Account a)
{
	int res;
	
	if(a.getBalance() >= amt)
	{
		res= a.getBalance() - amt;
		 System.out.println("Balance amount after withdraw: "+res); 
		return true;
	}
	else
	{
		System.out.println("Sorry!!! No enough balance");
		return false;
	}
}
}
