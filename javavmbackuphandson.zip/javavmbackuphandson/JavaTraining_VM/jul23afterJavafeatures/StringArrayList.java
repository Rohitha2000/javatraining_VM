import javax.print.attribute.standard.NumberUp;
import java.util.*;
public class StringArrayList {
	public static boolean isNumeric(String str) {
        return str != null && str.matches("[-+]?\\d*\\.?\\d+");
    }
	public static void printAll(ArrayList<String> arr)
	{
		 Iterator<String> iter = arr.iterator();
		 while (iter.hasNext()) {
	            System.out.print(iter.next() + " ");
	        }
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> arr= new ArrayList<String>();
		Scanner s= new Scanner(System.in);
		while(true)
		{
			String str= s.next();
			if(isNumeric(str))
			{
				System.out.println("Cannot enter number as String");
				System.exit(0);
			}
			else if(str.equalsIgnoreCase("quit"))
			{
				printAll(arr);
				System.exit(0);
			}
			else
			{
				arr.add(str);
			}
		}
	}

}
