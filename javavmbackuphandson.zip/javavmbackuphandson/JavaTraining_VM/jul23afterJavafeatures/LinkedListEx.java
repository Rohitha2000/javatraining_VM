import java.util.ArrayList;
import java.util.LinkedList;

public class LinkedListEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList<String> month= new LinkedList<String>();
		month.add("January");
		month.add("February");
		month.add("March");
		month.add("April");
		month.add("May");
		month.add("June");
		month.add("July");
		month.add("August");
		month.add("Spetember");
		month.add("October");
		month.add("November");
		month.add("December");
		for(String st: month)
			System.out.print(st+" | ");
	}

}
