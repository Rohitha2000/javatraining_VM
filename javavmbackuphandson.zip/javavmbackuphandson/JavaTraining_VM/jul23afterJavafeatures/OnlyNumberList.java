import java.util.*;

public class OnlyNumberList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Object> obj1 = new ArrayList<Object>();
		Scanner s= new Scanner(System.in);
		int i=1;
		obj1.add(12);
		obj1.add(23.34);
		obj1.add(23.4F);
		obj1.add(10L);
		obj1.add(10);
		obj1.add("Rohi");
		for(Object obj: obj1)
		{
			
			
			if (obj.getClass() == String.class) {
		        System.out.println("Cannot insert String: " + obj);
		        System.exit(0);
		    }
			else if (obj.getClass() == Integer.class) {
		        System.out.println("I found an int : " + obj);
		    }
			else if (obj.getClass() == Float.class) {
		        System.out.println("I found a float : " + obj);
		    }
			else if (obj.getClass() == Double.class) {
		        System.out.println("I found a double : " + obj);
		    }
			else if (obj.getClass() == Long.class) {
		        System.out.println("I found a long : " + obj);
		    }
			else if (obj.getClass() == Short.class) {
		        System.out.println("I found a short : " + obj);
		    }
		}
	}

}
