class Main

{

 public static void main(String[] args)

 {

 int a=10,b,c=0;

 b=Integer.parseInt(args[0]);

 try{

  System.out.println("in the try block");

  c=a/b;

 }

 catch(ArithmeticException e) {

  System.out.println("exception..");

 }

 finally {

  System.out.println("finally block");

 }

 System.out.println("c value is "+c);

 System.out.println("end of the prg");

 }

}