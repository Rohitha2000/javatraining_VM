
 class MyException extends Exception

{

 public MyException()

 {

 System.out.println("MyException ");

 }

 public MyException(String s)

 {

 System.out.println("MyException ........... "+s);

 }

}




public class ThrowTest

{

 public void disp(int age)throws MyException

 {

 if(age<0)

 {

  System.out.println("inside the if block");

  try{

  throw new MyException("U should not pass negative numbers");////system defined exception

  }catch (Exception e) {

  System.out.println(e.getMessage()+" eeeeeeee");

  }

  }

 else

 {

  System.out.println("value is "+age);

 }

 }//method

 public static void main(String[] args)throws MyException

 {

  ThrowTest td=new ThrowTest();

  td.disp(-5);

 System.out.println("end of p rg");

 }//main

}//class

