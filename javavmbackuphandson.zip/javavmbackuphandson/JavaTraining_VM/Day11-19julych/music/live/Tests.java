package music.live;
import music.*;
import music.string.Veena;
import music.wind.Saxophone;
public class Tests {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Playable ve= new Veena();

        Playable sa= new Saxophone();
        ve.play();
        sa.play();
	}

}
