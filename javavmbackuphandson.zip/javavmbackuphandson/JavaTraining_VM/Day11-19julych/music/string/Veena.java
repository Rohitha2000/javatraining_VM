package music.string;
import java.util.*;

import music.Playable;
public class Veena implements Playable
{
  public void play()
 {
	 System.out.println("playing veenaa");
 }
}
