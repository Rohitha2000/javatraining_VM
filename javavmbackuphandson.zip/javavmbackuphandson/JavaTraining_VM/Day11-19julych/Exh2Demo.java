 class Exh2Demo

{

 public static void main(String[] args)

 {

 int a=10,b;

 try

 {

 System.out.println("before parseInt");

 b=Integer.parseInt(args[0]);

 System.out.println("after parseInt");

  int c;

  c=a/b;

System.out.println("c value is "+c);

System.out.println("end of try");

 }

 catch(ArithmeticException ae)

 {

System.out.println("arithmetic error -catch block "+ae.getMessage());

 }

 catch(ArrayIndexOutOfBoundsException aioe)

 {

  System.out.println(aioe);

 }

 catch(Exception e)

 {

  System.out.println("SSSSSSSSSSSSSSSSS");

  e.printStackTrace();

 }

 finally

 {

  System.out.println("finally block");

 }

 System.out.println("end of the prg");

 }

}