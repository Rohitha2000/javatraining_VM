package StudentDetails;
import java.util.*;

public class handson6day2{
	
	public handson6day2(int id, String name, String addr)
	{
		System.out.println("Student id: "+ id);
		System.out.println("Student name: "+ name);
		System.out.println("Student address: "+ addr);
		System.out.println("Student college: NIT");
	}
	public handson6day2(int id, String name, String addr, String clg)
	{
		System.out.println("Student id: "+ id);
		System.out.println("Student name: "+ name);
		System.out.println("Student address: "+ addr);
		System.out.println("Student college: "+clg);
	}
	public static void main(String args[])
	{
		int id;
		String name, addr, nit, clg, y= "yes", n="no";
		Scanner s= new Scanner(System.in);
		System.out.println("Enter student id: ");
		id= s.nextInt();
		System.out.println("Enter student name: ");
		name= s.next();
		System.out.println("Enter student address: ");
		addr= s.next();
		System.out.println("Whether the student is from NIT(Yes/No):");
		nit= s.next();
		
		if(nit.equalsIgnoreCase(y))
		{
			handson6day2 st= new handson6day2(id,name, addr);
		}
		else if(nit.equalsIgnoreCase(n))
		{
			System.out.println("Enter college name");
			clg= s.next();
			handson6day2 st= new handson6day2(id,name, addr, clg);
		}
		else 
		{
			System.out.println("Wrong");
			return;
		}
}
}
