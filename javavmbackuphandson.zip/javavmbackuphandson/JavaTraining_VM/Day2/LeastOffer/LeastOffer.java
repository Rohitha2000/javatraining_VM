package LeastOffer;
import java.util.*;
public class LeastOffer {
  
	public static void main(String[] args) {
		// TODO Auto-genera ted method stub
		int noofitems,i,j;
		float k;
        
      Scanner s = new Scanner(System.in);
      noofitems= s.nextInt();
      String[] product= new String[noofitems];
      float[] price= new float[noofitems];
      float[] discount= new float[noofitems];
      float[] total= new float[noofitems];
      for (i = 0; i < noofitems;i++)
      {
    	  System.out.println("enter product name");
          product[i] = s.next(); // enter product names
          System.out.println("enter price");
          price[i]= s.nextInt();
          System.out.println("enter discount");
          discount[i]= s.nextInt();
         
      }
      for(i=0;i<noofitems;i++)
      {
    	  
    	  total[i]= price[i]*(discount[i]/100);
    	 // System.out.println(total[i]);
      }
      float res= total[0];
      for(i=1;i<noofitems;i++)
      {
    	 
    	  if(total[i]< res)
    	  {
    		  res= total[i];
    		//  System.out.println("ress   "+res);
    	  }
    	  if(i== noofitems-1)
    	  {
    		//  System.out.println(" fiunal ress   "+res);
    		  System.out.println("Least Offer: ");
    		  for(j=0;j<noofitems;j++)
    		  {
    			  if(res== total[j])
    			  {
    				  System.out.println(product[j]);
    			  }
    		  }
    		 
    	  }
    	 
      }
      
      
	}

}

