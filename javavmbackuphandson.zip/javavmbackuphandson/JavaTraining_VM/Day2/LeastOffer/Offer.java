package LeastOffer;


	class Offer
	{
		String name;
		int price;
		int discount;
		float afterdisc;
	}
