package TicketPrice;

public class Ticket {
  private int ticketid;
private int price;
private static int availabletickets;
static int ticketsAfterBooking;
public int getTicketid() {
	return ticketid;
}
public void setTicketid(int ticketid) {
	this.ticketid = ticketid;
}
public int getPrice() {
	return price;
}
public void setPrice(int price) {
	this.price = price;
}
public static int getAvailabletickets() {
	return availabletickets;
}
public static void setAvailabletickets(int availabletickets) {
	Ticket.availabletickets = availabletickets;
}

public int calculateTicketCost(int nooftickets)
{
	int totalprice;
	if(availabletickets> 0)
	{
		ticketsAfterBooking = availabletickets - nooftickets;
	}
	else
	{
		return -1;
	}
	totalprice= nooftickets* price;
	return totalprice;
	
}
//public int ticketafter()
//{
//	return ticketsAfterBooking;
//}
}
