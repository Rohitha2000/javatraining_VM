package TicketPrice;
import java.util.*;
public class TicketTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      int bookings,i, ticketid, price, nooftickets, res;
      int availabletickets;
      Scanner s= new Scanner(System.in);
      System.out.println("Enter the no of bookings");
      bookings= s.nextInt();
      System.out.println("Enter available tickets");
      availabletickets= s.nextInt();
      Ticket t= new Ticket();
      for(i=0; i<bookings; i++)
      {
      System.out.println("Enter ticketid");
       ticketid= s.nextInt();
       t.setTicketid(ticketid);
       System.out.println("Enter the price");
       price= s.nextInt();
       t.setPrice(price);
       System.out.println("Enter no of tickets");
       nooftickets= s.nextInt();
       System.out.println("Available tickets");
       availabletickets= s.nextInt();
       t.setAvailabletickets(availabletickets);
       res= t.calculateTicketCost(nooftickets);
       System.out.println("Total amount: "+ res);
       System.out.println("Available tickets after booking: "+ t.ticketsAfterBooking);
       
	}
	}
}
