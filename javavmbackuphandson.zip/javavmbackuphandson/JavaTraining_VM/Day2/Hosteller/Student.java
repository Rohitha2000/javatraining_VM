package Hosteller;
	public class Student
	{
		protected int id;
		protected String name;
		protected int dept;
		protected String gender;
		protected String phone;
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public int getDept() {
			return dept;
		}
		public void setDept(int dept) {
			this.dept = dept;
		}
		public String getGender() {
			return gender;
		}
		public void setGender(String gender) {
			this.gender = gender;
		}
		public String getPhone() {
			return phone;
		}
		public void setPhone(String phone) {
			this.phone = phone;
		}

	}
	

