package Hosteller;

import java.util.Scanner;

public class Main {

	
		
		
	public static Hosteller  getHostellerDetails()
	{
			 int stid, stdept, stroom;
				String stname, stgen, stphone, sthostl;
				char mroom, mphone;
				Hosteller obj= new Hosteller();
				Scanner s= new Scanner(System.in);
				 System.out.println("Enter the details");
		    System.out.println("Enter Student id");
		  stid= s.nextInt();
		    obj.setId(stid); // Set id
		    
		    System.out.println("Enter Student Name");
		    stname = s.next();
		    obj.setName(stname); // set name
		    
		    System.out.println("Enter Department id");
		    stdept= s.nextInt();
		    obj.setDept(stdept);// set dept
		    
		    System.out.println("Enter Student Gender");
		    stgen = s.next();
		    obj.setGender(stgen); // set gender
		    
		    System.out.println("Enter Student phone");
		    stphone = s.next();
		    obj.setPhone(stphone); // set phone
		    
		    System.out.println("Enter Hostel name");
		    sthostl = s.next();
		    obj.setHostel(sthostl); // set hostl
		    
		    System.out.println("Enter Room no");
			  stroom= s.nextInt();
			    obj.setRoom(stroom); // Set room
			    
			 System.out.println("Modify room no (Y/N)");
			 mroom= s.next().charAt(0);
			 if(mroom== 'y' || mroom== 'Y')
			 {
				 System.out.println("Enter new room no ");
				 stroom= s.nextInt();
				    obj.setRoom(stroom); // Set room
			 }
			 System.out.println("Modify phone no (Y/N)");
			 mphone= s.next().charAt(0);
			 if(mphone == 'y' || mphone== 'Y')
			 {
				 System.out.println("Enter new phone no ");
				 stphone= s.next();
				    obj.setPhone(stphone); // Set room
			 }
		 
		 System.out.println("Student Details");
		 System.out.print(obj.getId()+" ");
		 System.out.print(obj.getName()+" ");
		 System.out.print(obj.getDept()+" ");
		 System.out.print(obj.getGender()+" ");
		 System.out.print(obj.getPhone()+" ");
		 System.out.print(obj.getHostel()+" ");
		 System.out.print(obj.getRoom()+" ");
		s.close();
		return obj;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Hosteller host= new Hosteller();
	host= getHostellerDetails();
	}
}



