package FuelConsumption;
import java.util.*;
public class handson4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// FUEL CONSUMPTION
		

double lit, dist,likm,dist1, lit1, res, mid;
 Scanner s= new Scanner(System.in);
 System.out.println("Enter the no of liters to fill the tank:");
 lit= s.nextDouble();
 if(lit<0)
 {
	 System.out.println(String.format("%.0f", lit)+" is an invalid input");
	 return;
 }

 
 System.out.println("Enter the distance covered: ");
 dist= s.nextDouble();
 if(dist<0)
 {
	 System.out.println(String.format("%.0f", dist)+" is an invalid input");
     return;
 }
 
 mid= lit/dist;
 //System.out.println(mid);
 likm= mid * 100;
 dist1= dist * 0.6214;
 lit1= lit* 0.2642;
 res= dist1/lit1;
 System.out.println("Liters/100KM");
 System.out.println(String.format("%.2f", likm));
 System.out.println("Miles/gallons");
 System.out.println(String.format("%.2f", res));
	}

}
