package BillGeneration;
import java.util.*;
public class handson3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// BILL PAYMENT
 int piz=100, puf=20, cd=10;
 int a,b,c;
 Scanner s=new Scanner(System.in);
 System.out.println("Enter the no of pizzas bought:");
 a= s.nextInt();
 System.out.println("Enter the no of puffs bought:");
	b= s.nextInt();
	 System.out.println("Enter the no of cooldrinks bought:");
	c= s.nextInt();
	int t= piz*a + puf*b+ cd*c; 
	System.out.println("Bill Details");
	System.out.println("No of pizzas: " + a);
	System.out.println("No of puffs: " + b);
	System.out.println("No of cooldrinks: " + c);
	System.out.println("Total Price= "+ t);
	System.out.println("ENJOY THE SHOW!!!");
	}

}
