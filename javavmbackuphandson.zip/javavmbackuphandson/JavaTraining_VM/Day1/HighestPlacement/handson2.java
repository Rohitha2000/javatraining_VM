package HighestPlacement;
import java.util.*;
public class handson2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// HIGHEST PLACEMENT
  int cse, ece, mech;
  Scanner s= new Scanner(System.in);
  System.out.println("Enter the no of students placed in CSE:");
  cse= s.nextInt();
  System.out.println("Enter the no of students placed in ECE:");
  ece= s.nextInt();
  System.out.println("Enter the no of students placed in MECH:");
  mech= s.nextInt();
  if(cse==0 && ece==0 && mech==0)
  {
	  System.out.println("None of the department has got the highest placement");
	  
  }
  else if(cse<0 || ece<0 || mech<0)
  {
	  System.out.println("Input is invalid");
  }
  if(cse>=0 && ece>=0 && mech>=0)
  {
   if(cse> ece)
    {
	  if(cse> mech)
	  {
		  System.out.println("Highest Placement"+"\n"+ "CSE");
	  }
	  else if(cse == mech)
	  {
		  System.out.println("Highest Placement"+"\n"+"CSE"+ "\n"+"MECH");
	  }
	  else
	  {
		  System.out.println("Highest Placement"+"\n" + "MECH");
	  }
  }
  else if(ece== cse)
  {
	  System.out.println("Highest Placement:"+ "\n"+"CSE"+ "\n"+ "ECE");
	  
  }
  else if(ece> mech)
  {
	  System.out.println("Highest Placement" + "\n"+"ECE");
  }
  else if(ece == mech)
  {
	  System.out.println("Highest Placement"+ "\n"+ "ECE"+ "\n"+"MECH ");
  }
  else if(mech> ece)
  {
	  System.out.println("Highest Placement"+ "\n"+"MECH");
  }
	}
	}

}
