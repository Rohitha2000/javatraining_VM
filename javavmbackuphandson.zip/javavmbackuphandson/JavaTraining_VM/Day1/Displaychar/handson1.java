package Displaychar;
import java.util.*;
public class handson1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// DISPLAY CHARACTERS
		
   int a,b,c,d;
   Scanner s= new Scanner(System.in);
   a= s.nextInt();
   b= s.nextInt();
   c= s.nextInt();
   d= s.nextInt();
   
   System.out.println(a+"-"+ (char)a);
   System.out.println(b+"-"+ (char)b);
   System.out.println(c+"-"+ (char)c);
   System.out.println(d+"-"+ (char)d);
	}

}
