package MovieTicket;
import java.util.*;
public class handson5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//  MOVIE TICKET
   int t;
   double cost,cost1, ct;
   char a,b,c;
   Scanner s= new Scanner(System.in);
   System.out.println("Enter the no of ticket: ");
   t= s.nextInt();
   if(t< 5 || t>40)
   {
	   System.out.println("Minimum of 5 and Maximum of 40 Tickets");
	   return;
   }
   System.out.println("Do u want refreshment");
   a= s.next().charAt(0);
   System.out.println("Do u have coupon code");
   b= s.next().charAt(0);
   System.out.println("Enter the circle");
   c= s.next().charAt(0);
   if(c== 'k')
   {
	   cost= t*75; // king
   }
   else if(c== 'q')
   {
	   cost= t*150;// queen
   }
   else
   {
	   System.out.println("Invalid input");
	   return;
   }
   // if tickets are greater than 20
   if(t>20)
   {
	   cost1= cost- (cost* 0.10); // 10% discount
	   if(b== 'y' && a=='y')
	   {
		   cost1= cost1- (cost1*0.02); // 2% discount
		   ct= cost1 + t*50; // refreshment
		   System.out.println("Ticket Cost: "+ ct);
		   return;
	   }
	   else if(a== 'y' && !(b=='y'))
	   {
		   ct= cost1 + t*50; // refreshment
		   System.out.println("Ticket Cost: "+ ct);
		   return;
	   }
	   else if(b== 'y' && !(a=='y'))
	   {
		   cost1= cost1- (cost1*0.02);
		   System.out.println("Ticket Cost: "+ cost1);
		   return;
	   }
	   else
	   {
		   System.out.println("Ticket Cost: "+ cost1);
		   return;
	   }
	   
   }
   // if tickets are less than 20
   else if(t<=20 && t>0)
   {
     if(b== 'y' && a=='y')//coupon b
     {
	   cost= cost-(cost*0.02);//b
	   ct= cost + t*50; // refresh a
	   System.out.println("Ticket Cost: "+ ct);
	   return;
     }
     else if(a== 'y'&& !(b=='y'))
     {
    	 
  	   ct= cost + t*50; // refresh
	   System.out.println("Ticket Cost: "+ ct);
	   return;
     }
     else if(!(a=='y') && b== 'y')
     {
    	 cost= cost-(cost*0.02);
    	 System.out.println("Ticket Cost: "+ cost);
  	     return;
     }
   
	}

}
}
