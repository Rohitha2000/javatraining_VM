package AverageAge;
import java.util.*;
public class Avgage {
public static double calculateAverage()
{
	int num,i;
Scanner s= new Scanner(System.in);
num= s.nextInt();
int[] arr= new int[num];
for(i=0;i<num;i++)
{
	  arr[i]= s.nextInt();
}
	int sum=0;
	for(i=0;i<num;i++)
	{
		sum= sum+ arr[i];
	}
	double avg= sum/num;
	return avg;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
 
 double res= calculateAverage();
 System.out.println("Average age: "+res);
	}

}
