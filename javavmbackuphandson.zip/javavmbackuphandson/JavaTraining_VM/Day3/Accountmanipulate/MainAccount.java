package Accountmanipulate;

public class MainAccount {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  Customer cus=new Customer(1234,"rohi","@gmail");
	        Savingsaccount sa=new Savingsaccount(123,cus,1000,500);
	        boolean flag=sa.withdraw(500);
	        if(flag){
	            System.out.println(sa.getBalance());
	            System.out.println("Successful!");
	        }
	        else{
	            System.out.println("not enough balance");
	        }

	}

}
