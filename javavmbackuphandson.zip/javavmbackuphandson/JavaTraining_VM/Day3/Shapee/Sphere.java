package Shapee;
import java.util.*;
public class Sphere extends Shape{
    private double radius;

	public double getRadius() {
		return radius;
	}

	public void setRadius(double radius) {
		this.radius = radius;
	}
    public double area()
    {
    	double area= 4* Math.PI*radius *radius;
    	return area;
    }
    public double volume()
    {
    	double volume= (4* Math.PI*radius *radius*radius)/3;
    	return volume;
    }
}
