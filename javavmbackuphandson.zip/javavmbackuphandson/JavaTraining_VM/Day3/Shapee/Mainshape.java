package Shapee;
import java.util.*;
public class Mainshape {
	static void triangle()
	{
		Scanner s= new Scanner(System.in);
     	double trib, trih;
      Triangle tri= new Triangle();
	  System.out.println("Trinagle");
	  trib= s.nextDouble();
	  trih= s.nextDouble();
	  tri.setBase(trib);
	  tri.setHeight(trih);// trianglev
	  System.out.println("Area: "+tri.area());

	}
	static void tri()
	{
		Triangle t= new Triangle();
		//System.out.println("Area: "+t.area());
	}
	static void sphere()
	{
		Scanner s= new Scanner(System.in);
		
		Sphere sp= new Sphere();
		double spr;
		System.out.println("Sphere");
		spr= s.nextDouble();
		sp.setRadius(spr);// sphere
		System.out.println("Area: "+ sp.area());
		System.out.println("Volume: "+sp.volume());
	}
	static void sph()
	{
		Sphere sp= new Sphere();
//		System.out.println("Area: "+ sp.area());
//		System.out.println("Volume: "+sp.volume());
	}
	static void rectangle()
	{
		Scanner s=new Scanner(System.in);
		Rectangle rec= new Rectangle();
		double len,wid;
		System.out.println("Rectangle");
		len= s.nextDouble();
		wid= s.nextDouble();
		rec.setLength(len);
		rec.setWidth(wid);
		System.out.println("Area: "+ rec.area());
	}
	static void rec()
	{
		Rectangle r= new Rectangle();
		//System.out.println("Area: "+ r.area());
	}
	static void cube()
	{
		Scanner s=new Scanner(System.in);
		Cube c= new Cube();
		double len, wid, hei;
		System.out.println("Cube");
		len= s.nextDouble();
		wid= s.nextDouble();
		hei= s.nextDouble();
		c.setLength(len);
		c.setWidth(wid);
		c.setHeight(hei);
		System.out.println("Area: "+ c.area());
		System.out.println("Volume: "+c.volume());
	}
	static void cub()
	{
		Cube c= new Cube();
//		System.out.println("Area: "+ c.area());
//		System.out.println("Volume: "+c.volume());
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter shapes and measures");
		Scanner s=new Scanner(System.in);
		String[] arr= new String[5];
		for(int i=0;i<5;i++)
		{
			arr[i]= s.next();
		}
		for(int j=0;j<5;j++)
		{
			switch(arr[j])
			{
			case "triangle": 
				Mainshape.triangle();
			    break;
			case "sphere":
				 Mainshape.sphere();
				 break;
			case "rectangle":
				Mainshape.rectangle();
				break;
			case "cube":
				Mainshape.cube();
				break;
			default:
				System.out.println("Invalid");
				break;
			}
			
		}
//		for(int k=0;k<5;k++)
//		{
//			switch(arr[k])
//			{
//			case "triangle": 
//				Mainshape.tri();
//			    break;
//			case "sphere":
//				 Mainshape.sph();
//				 break;
//			case "rectangle":
//				Mainshape.rec();
//				break;
//			case "cube":
//				Mainshape.cub();
//				break;
//			default:
//				System.out.println("Invalid");
//				break;
//			}
//			
//		}
    
	}

}
