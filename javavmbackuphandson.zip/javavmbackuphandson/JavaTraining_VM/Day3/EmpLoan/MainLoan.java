package EmpLoan;
import java.util.*;
public class MainLoan{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ClassLoaan cl= new ClassLoaan();
		//Employee e= new Employee();
		Scanner s= new Scanner(System.in);
		int id;
		String name;
		double pa;
		System.out.println("enter employee id");
	    id= s.nextInt();
       System.out.println("Enter name");
	   name=s.next();
	   System.out.println("pay");
	   pa= s.nextDouble();
	   Employee el= new PermanentEmployee(id, name, pa);
	  System.out.println(cl.calculateLoanAmount(el));
	}

}
