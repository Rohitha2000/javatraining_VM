package EmpLoan;
import java.util.*;
public class ClassLoaan{
	public double calculateLoanAmount(Employee employeeObj)
	{
	
		Scanner s= new Scanner(System.in);
		double t, per;
		System.out.println("Enter 1 for permanenet employee");
		System.out.println("Enter 2 for temporary employee");
		int num= s.nextInt();
		if(num ==1)
		{
			per= (double)15/100;
			int id;
			double pay;
			double loan1;
			String name;
			//Scanner s= new Scanner(System.in);
//			System.out.println("enter employee id");
//			id= s.nextInt();
//			System.out.println("Enter name");
//			name=s.nextLine();
			System.out.println("enter basic pay");
			pay= s.nextDouble();
			PermanentEmployee pe= new PermanentEmployee(employeeObj.employeeId, employeeObj.employeeName, pay);
			pe.setBasicPay(pay);
			pe.calculateSalary();
			loan1= per*pe.getBasicPay();
			return loan1;
		}
		else if(num== 2)
		{
			per= (double)10/100;
			int id;
			double pay,k;
			double loan2, tempsal;
			int wage, work;
			String name;
//			//Scanner s= new Scanner(System.in);
//			System.out.println("enter employee id");
//			id= s.nextInt();
//			System.out.println("Enter name");
//			name=s.nextLine();
			System.out.println("enter hours worked");
			work= s.nextInt();
			System.out.println("enter hourly wages");
            wage = s.nextInt();
			TemporaryEmployee pe= new TemporaryEmployee(employeeObj.employeeId, employeeObj.employeeName, work, wage);
			pe.calculateSalary();
			pay= per*pe.getSalary();
			return pay;
		}
		return 0;

	}
}
