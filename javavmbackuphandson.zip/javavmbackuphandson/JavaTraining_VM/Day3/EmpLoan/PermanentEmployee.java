package EmpLoan;
import java.util.*;
public class PermanentEmployee extends Employee{
private double basicPay;

public double getBasicPay() {
	return basicPay;
}

public void setBasicPay(double basicPay) {
	this.basicPay = basicPay;
}
public PermanentEmployee(int employeeId, String employeeName, double basicPay)
{
	super(employeeId, employeeName);
	System.out.println("permanenet emp");
}
public void calculateSalary()
{
	double salary,pay,k;
//	System.out.println("enter basic pay");
//	pay= s.nextDouble();
	
	//PermanentEmployee pe= new PermanentEmployee(id, name, pay);
	pay= getBasicPay();
	k=pay * 0.12;
	 salary = pay-k;
	 this.basicPay= salary;
}



}
