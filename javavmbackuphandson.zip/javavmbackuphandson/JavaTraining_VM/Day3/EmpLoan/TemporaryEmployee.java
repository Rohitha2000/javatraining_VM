package EmpLoan;

public class TemporaryEmployee extends Employee {
   private int  hoursWorked;
   private int hourlyWages;
   static double sal= 10;
    public int getHoursWorked() {
	return hoursWorked;
}
public void setHoursWorked(int hoursWorked) {
	this.hoursWorked = hoursWorked;
}
public int getHourlyWages() {
	return hourlyWages;
}
public void setHourlyWages(int hourlyWages) {
	this.hourlyWages = hourlyWages;
}
	

	public TemporaryEmployee(int employeeId, String employeeName, int hoursWorked, int hourlyWages)
	{
		super(employeeId, employeeName);
		this.hourlyWages = hourlyWages;
		this.hoursWorked = hoursWorked;
		System.out.println("temp emp");
	}
	public void calculateSalary()
	{
        salary = hoursWorked * hourlyWages;
        this.salary= salary;
        
	}

	
}
