package VehicleLoan;

public interface Insurance {
	abstract double takeInsurance();
}
