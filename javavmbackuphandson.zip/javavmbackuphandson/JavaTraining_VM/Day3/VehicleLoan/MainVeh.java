package VehicleLoan;
import java.util.*;
public class MainVeh {
	public static void main(String args[])
	{
	String vehicleNumber;
    String modelName;
    int vehicleType;
    double price;
    System.out.println("enter vehicle number");
   Scanner s= new Scanner(System.in);
   vehicleNumber= s.next();
  System.out.println("enter model name");
   modelName= s.next();
  System.out.println("enter vehicle type");
   vehicleType= s.nextInt();
  System.out.println("enter price");
   price= s.nextDouble();
   System.out.println(price);
   
 //  Vehicle v= new Vehicle("ts80001", "pridehonda", "4wheeler", 900000);
    Vehicle v= new Vehicle(vehicleNumber, modelName, vehicleType, price);
    System.out.println("Loan: "+ v.issueLoan());
    System.out.println("insurance: "+v.takeInsurance());
    
	}
}
