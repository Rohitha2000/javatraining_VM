import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.*;
class InvalidDataException extends Exception{  
	InvalidDataException(String s){  
		  super(s);  
		 }  
		}  
public class Studentmarks {
	public static boolean isNumeric(String str) {
        return str != null && str.matches("[-+]?\\d*\\.?\\d+");
    }
	public static void main(String[] args) throws InvalidDataException, IOException{
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	
		System.out.println("enter Student name");
		String name1 = br.readLine();
		if(isNumeric(name1))
			throw new InvalidDataException("Name is numeric");
			
		System.out.println("Enter english marks");
		int eng= Integer.parseInt(br.readLine());
		if(eng <0)
			throw new InvalidDataException("input is invalid");
		
		System.out.println("Enter maths marks");
		int math= Integer.parseInt(br.readLine());
		if(math<0)
			throw new InvalidDataException("input is invalid");
		
		System.out.println("Enter science marks");
		int sci= Integer.parseInt(br.readLine());
		if(sci<0)
			throw new InvalidDataException("input is invalid");
		
		int avg1= (eng+ math+sci)/3;
		System.out.println("Average marks of "+name1+" is :  "+avg1);
		
		
		System.out.println("enter Student name");
		String name2 = br.readLine();
		System.out.println("Enter english marks");
		int eng1= Integer.parseInt(br.readLine());
		if( eng1<0)
			throw new InvalidDataException("input is invalid");
		
		System.out.println("Enter maths marks");
		int math1= Integer.parseInt(br.readLine());
		if( math1<0)
			throw new InvalidDataException("input is invalid");
		
		System.out.println("Enter science marks");
		int sci1= Integer.parseInt(br.readLine());
		if(sci1<0)
			throw new InvalidDataException("input is invalid");
		int avg2= (eng1+ math1+sci1)/3;
		System.out.println("Average marks of "+name2+" is :  "+avg2);
		
	}

}
