public class StringFunctions {

public static void main(String ar[]){

   String s1="hello";

   String s2="hello";

   System.out.println(s1.hashCode()+" "+s2.hashCode());

  if(s1==s2)

      System.out.println("both are equal");

  else

    System.out.println("both are not equal");

  if(s1.equals(s2))

      System.out.println("equals method both are equal");

  else

    System.out.println("both are not equal");
  System.out.println("new prog");
  String s11="hello";//olleh

  String str="";

  for(int i=s11.length()-1;i>=0;i--)

    str=str+s11.charAt(i);

   System.out.println(str);

  StringBuffer sb=new StringBuffer(str);

  System.out.println(sb.reverse());
  
  
  System.out.println("new prog");
  String s="hello";
  System.out.println(s.toUpperCase());

  System.out.println(s.charAt(0));

  char ch[]=s.toCharArray();

  for(char a : ch)

  System.out.print(a);



}}