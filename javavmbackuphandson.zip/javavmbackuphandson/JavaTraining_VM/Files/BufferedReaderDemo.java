import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class BufferedReaderDemo {

	public static void main(String[] args) throws IOException {

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter employee number");
		String empno = br.readLine();
		System.out.println("enter employee name");
		String ename = br.readLine();
		System.out.println("enter employee salary");
		double sal = Double.parseDouble(br.readLine());
		System.out.println(empno + " " + ename + " " + sal);

	}

}