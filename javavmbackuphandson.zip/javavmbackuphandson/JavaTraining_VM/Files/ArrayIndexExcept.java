import java.util.*;

public class ArrayIndexExcept {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		int num;
		System.out.println("Enter size of the array");
		num = s.nextInt();
		System.out.println("Enter elements");
		int arr[] = new int[num];
		for (int i = 0; i < num; i++) 
		{
			arr[i] = s.nextInt();
		}
		try
		{
			System.out.println("Enter index to show value");
			int x;
			x= s.nextInt();
//			for(int j=0;j<num;j++)
//			{
//				if(x<0 || x>= num)
//				{
//					throw new ArrayIndexOutOfBoundsException("Index is out of Array Bounds");
//					
//				}
//				else if(x== j)
//				{
//					System.out.println("The element at "+x+" is:  "+arr[j]);
//				System.out.println("The array element successfully accessed");
//				
//				}
//				
//			}
			System.out.println("The element at "+x+" is:  "+arr[x]);
			System.out.println("The array element successfully accessed");
		}
		catch(ArrayIndexOutOfBoundsException e) {System.out.println("Index is out of Array Bounds");}
		
		
		
	}

}
