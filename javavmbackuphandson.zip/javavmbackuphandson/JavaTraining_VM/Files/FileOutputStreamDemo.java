import java.io.*;
import java.io.IOException;

public class FileOutputStreamDemo {

 public static void main(String[] args) throws IOException {

 FileOutputStream fos=new FileOutputStream("ab.txt");

 String s="Welcome to Java Programming.........";

 byte b[]=s.getBytes();

 fos.write(b);

 fos.flush();

 fos.close();

 System.out.println("success");
 
 FileInputStream fis=new FileInputStream("ab.txt");

 int i;

 while((i=fis.read())!=-1)

 {

  System.out.print((char)i);

 }

 System.out.println("success");

 }

}