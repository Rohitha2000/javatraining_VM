

import java.util.*;

public class NumberFormatExcept {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		String str;
		System.out.println("Enter input");
		str = s.next();
		try 
		{
			int x = Integer.parseInt(str);
			int sq= x*x;
			System.out.println("Square of the input: "+sq);
			System.out.println("Work has been done successfully");
		} 
		catch (NumberFormatException e)
        {
			
			System.out.println("Entered input is not a valid format for an integer.");
		}
		
		
	}

}
