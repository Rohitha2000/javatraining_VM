
public class MathOperation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=5, sum=0, avg;
		
		int arr[]= new int[num];
		try
		{
		for(int i=0;i<args.length;i++)  
		{
			arr[i]= Integer.parseInt(args[i]); 
			System.out.println(arr[i]);
			sum= sum+ arr[i];
		}
		System.out.println("Sum: "+sum);
		System.out.println("Average: " + sum/5);
		}catch(ArithmeticException a) {System.out.println(a);}
		catch(NumberFormatException n) {System.out.println(n);}
		catch(ArrayIndexOutOfBoundsException e) {System.out.println(e);}
		
	}

}
