import java.util.*;

public class Divisionex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int n1, n2;
Scanner s= new Scanner(System.in);
n1= s.nextInt();
n2= s.nextInt();
//try
//{
	
	if(n1/n2 == 0)
		throw new ArithmeticException("/ by 0");
//}catch(Exception e) {System.out.println(e);}
//	
	}

}
