import java.util.*;
class InvalidCountryException extends Exception{  
	 InvalidCountryException(String s){  
	  super(s);  
	 }  
	}  
public class RegisterUser {
	void registerUser(String username,String userCountry) throws InvalidCountryException
	{
		if(userCountry.equalsIgnoreCase("india"))
			System.out.println("User registration done successfully");
		else
			throw new InvalidCountryException("User Outside India cannot be registered");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub 
		RegisterUser rr= new RegisterUser();
		try
		{
		rr.registerUser("rohitha", "IndiA");
		}catch(InvalidCountryException e) {System.out.println(e);}
	}

}
