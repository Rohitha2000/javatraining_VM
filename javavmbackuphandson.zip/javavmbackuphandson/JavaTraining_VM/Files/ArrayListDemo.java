import java.util.*;
class ArrayListDemo
{
	public static void main(String[] args) {
		ArrayList<Integer> al= new 	ArrayList<Integer>();
		al.add(23);
		al.add(26);
		al.add(99);
		al.add(103);
		ListIterator li= al.listIterator();



		   while(li.hasNext())

		   {

		    System.out.println(li.next());

		   }

		   System.out.println("backword direction...........");

		    while(li.hasPrevious())

		    {

		    System.out.println(li.previous());

		    }

		   
	}
}