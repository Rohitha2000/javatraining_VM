public class StringDemo {



 public static void main(String[] args) {

 String s="Welcome to java Programming";

 System.out.println(s.substring(11,15));

 System.out.println(s.substring(11));

 System.out.println(s.indexOf('e'));

 System.out.println(s.lastIndexOf('o'));

 byte b[]=s.getBytes();

 for(byte r : b)

  System.out.print((char)r);

 String s1=s.valueOf(5);

 System.out.println("\n"+s1);

 }

}