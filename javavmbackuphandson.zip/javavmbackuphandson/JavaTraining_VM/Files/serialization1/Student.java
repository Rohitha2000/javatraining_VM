package serialization1;
import java.io.Serializable;

public class Student implements Serializable{

 private int id;

 private transient String name;

public Student(int id, String name) {

 super();

 this.id = id;

 this.name = name;

}

public int getId() {

 return id;

}

public String getName() {

 return name;

}

}  

