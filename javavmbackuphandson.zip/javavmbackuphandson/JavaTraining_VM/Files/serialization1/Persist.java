package serialization1;

import java.io.*;

class Persist{

 public static void main(String args[]){

 try{

 //Creating the object

 Student s1 =new Student(211,"ravi");

 //Creating stream and writing the object

 FileOutputStream fout=new FileOutputStream("vm.txt");

 ObjectOutputStream out=new ObjectOutputStream(fout);

 out.writeObject(s1);

 //deserialization

 ObjectInputStream in=new ObjectInputStream(new FileInputStream("vm.txt"));

 Student s=(Student)in.readObject();

 //printing the data of the serialized object

 System.out.println(s.getId()+" "+s.getName());

 System.out.println("success");

 }catch(Exception e){System.out.println(e);}

 }

}  