
public class ThreadJoin1 extends Thread{
	public void run()
	{
		  try{  
			    Thread.sleep(500);  
			   }catch(Exception e){System.out.println(e);}  
		for(int i=0;i<5;i++)
		{
			System.out.println("Thread "+i);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ThreadJoin1 tj1= new ThreadJoin1();
		ThreadJoin1 tj2= new ThreadJoin1();
		ThreadJoin1 tj3= new ThreadJoin1();
		tj1.start();
		
// join method allows tj1 thread to complete execution by stopping tj2 and tj3 threads
		
		try {
			tj1.join();	
		}
		catch(Exception e)
	{
			System.out.println();
		}
      tj2.start();
      tj3.start();
	}

}
