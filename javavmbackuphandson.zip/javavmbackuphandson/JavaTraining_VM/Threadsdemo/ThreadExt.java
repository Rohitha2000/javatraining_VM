import java.util.*;

public class ThreadExt extends Thread {

	public void run() {
	for (int i = 0; i < 5; i++) {
			System.out.println("Thread running");

		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ThreadExt st = new ThreadExt();

	st.start();

	}

}
