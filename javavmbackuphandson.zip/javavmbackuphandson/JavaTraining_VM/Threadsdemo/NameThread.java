
public class NameThread extends Thread{
public void run()
{
	System.out.println(Thread.currentThread().getName());
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
       NameThread nt1= new NameThread();
       NameThread nt2= new NameThread();
      NameThread nt3= new NameThread();
       NameThread nt4= new NameThread();
       NameThread nt5= new NameThread();
       nt1.setName("TT1");
       nt2.setName("TT2");
       nt3.setName("TT3");
       nt4.setName("TT4");
       nt5.setName("TT5");
       
       nt1.start();
       nt2.start();
       nt3.start();
       nt4.start();
       nt5.start();
    
	}

}
