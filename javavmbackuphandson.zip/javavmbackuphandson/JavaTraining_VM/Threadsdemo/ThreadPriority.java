import java.lang.*;
public class ThreadPriority extends Thread {
    public void run()
    {
    	System.out.println(Thread.currentThread().getName());
    	System.out.println(Thread.currentThread().getPriority());
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	ThreadPriority tp1= new ThreadPriority();
		ThreadPriority tp2= new ThreadPriority();
		ThreadPriority tp3= new ThreadPriority();
		ThreadPriority tp4= new ThreadPriority();
		ThreadPriority tp5= new ThreadPriority();
		tp1.setName("TP1");
		tp2.setName("TP2");
		tp3.setName("TP3");
		tp4.setName("TP4");
		tp5.setName("TP5");
		  tp1.setPriority(1);  
		  tp2.setPriority(1);
		  tp3.setPriority(10);
		  tp4.setPriority(5);
		  tp5.setPriority(3);
		  tp1.start();
		  tp2.start();
		  tp3.start();
		  tp4.start();
		  tp5.start();
		  
	
		 
	}

}
