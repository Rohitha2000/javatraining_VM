import java.util.concurrent.*;
class Shared
{
	static int count=0;
}
class MyThread extends Thread
{
	
	Semaphore sem;
	String name;
	MyThread(Semaphore sem, String name)
	{
		super(name);
		this.sem= sem;
		this.name= name;
	}

@Override
public void run()
{
	if(name.equals("Producer"))
	{
		System.out.println("Starting Producer");
		try
		{
		System.out.println("producer waiting for permit");
		// sem gets lock to the resource
		sem.acquire();
		for(int i=0;i<4;i++)
		{
			Shared.count++;
			System.out.println(Thread.currentThread().getName()+" produced:  "+Shared.count);
			
			Thread.sleep(300);
		}
		
   	}catch(InterruptedException e) {System.out.println(e);}
		
		sem.release();
		System.out.println(Thread.currentThread().getName()+" releases the permit");
		
	}
	else
	{
		System.out.println("Starting Consumer");
		try
		{
		System.out.println("Consumer waiting for permit");
		// sem gets lock to the resource
		sem.acquire();
		for(int i=4;i>=1;i--)
		{
			Shared.count--;
			System.out.println(Thread.currentThread().getName()+" consumed:  "+Shared.count);
			
			Thread.sleep(300);
		}
		
		}catch(InterruptedException e) {System.out.println(e);}
		
		sem.release();
		System.out.println(Thread.currentThread().getName()+" releases the permit");
	}
}
}
public class Mysemaphore  {

	public static void main(String[] args) throws InterruptedException 
	{
		// TODO Auto-generated method stub
           Semaphore sem= new Semaphore(1);
           MyThread t1= new MyThread(sem, "Producer");
           MyThread t2= new MyThread(sem, "Consumer");
           
           t1.start();
           t2.start();
           
           t1.join();
           t2.join();
           
           System.out.println("Shared Count:  "+Shared.count);
	}

}
