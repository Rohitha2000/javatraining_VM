class Student1
{
	void print1(int n)
	{
//		for(int i=1;i<5;i++)
//		{
//			System.out.println(n*i);
//			try
//			{
//				Thread.sleep(300);
//			}catch(Exception e) {System.out.println(e);}
//		}
	synchronized(this)
		{

			for(int i=6;i<9;i++)
			{
				System.out.println(Thread.currentThread().getName()+"  ---- "+n*i);
			//	System.out.println(n*i);
				try
				{
					Thread.sleep(300);
				}catch(Exception e) {System.out.println(e);}
			}
		}
		for(int j=1;j<5;j++)
		{
			System.out.println(Thread.currentThread().getName()+"  ---- "+n*j);
			//System.out.println(n*i);
			try
			{
				Thread.sleep(300);
			}catch(Exception e) {System.out.println(e);}
		}
		
	}
}
 class Reach1 extends Thread
{
	Student1 st;
	Reach1(Student1 st)
	{
		this.st= st;
	}
	public void run()
	{
		st.print1(1);
	}
}
 class Reach2 extends Thread
{
	Student1 st;
	Reach2(Student1 st)
	{
		this.st= st;
	}
	public void run()
	{
		st.print1(100);
	}
}
public class SynchronizedBlock {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Student1 stu= new Student1();
      Reach1 r1= new Reach1(stu);
      Reach2 r2= new Reach2(stu);
      r1.start();
      r2.start();

	}

}
