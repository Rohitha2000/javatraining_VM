 class Anony1 extends Thread
{
	synchronized void printt(int n)
	{
		for(int i=0;i<5;i++)
		{
			System.out.println(i*n);
			try
			{
				Thread.sleep(300);
			}catch(Exception e) {System.out.println(e);}
		}
	}
}
public class SynchroMethodAnonymous {
	public static void main(String[] args) {
		
	
final Anony1 aa= new Anony1();
Thread t1= new Thread()
{
	public void run()
	{
		aa.printt(1);
	}
};
Thread t2= new Thread()
{
	public void run()
	{
		aa.printt(100);
	}
};
t1.start();
t2.start();
	}
}
