
public class ThreadRunn implements Runnable{
  public void run()
  {
  for(int i=0;i<5;i++)
	  {
	  System.out.println("Thread Running--- "+i);
	  }
  }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
       ThreadRunn tr= new ThreadRunn();
       Thread t1= new Thread(tr);
       t1.start();
	}

}
