 class Test1
{
	 synchronized void  printTest(int num)
	{
		for(int i=0;i<5;i++)
		{
			System.out.println(num*i);
			try
			{
				Thread.sleep(300);
		}catch(Exception e) {System.out.println(e);}
		}
	}
}
 class Thr1 extends Thread
 {
	 Test1 t;
	 Thr1(Test1 t)
	 {
		 this.t=t;
	 }
	public void run()
	 {
	 t.printTest(3);
 }
 }
 class Thread2 extends Thread
 {
	 Test1 t;
	 Thread2(Test1 t)
	 {
		 this.t=t;
	 }
	public void run()
	 {
	 t.printTest(300);
 }
 }
public class Synchronizedmethod {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	Test1 tt= new Test1();
		Thr1 t1= new Thr1(tt);
		Thread2 t2= new Thread2(tt);
		t1.start();
		t2.start();

	}

}
