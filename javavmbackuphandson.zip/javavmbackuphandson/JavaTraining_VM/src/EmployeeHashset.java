import java.util.HashSet;
import java.util.Iterator;

public class EmployeeHashset {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 HashSet<String> h2 = new HashSet<String>();
		 h2.add("rohitha");
		 h2.add("dhruv");
		 h2.add("visith");
		 h2.add("simran");
		 Iterator<String> iter= h2.iterator();
		 while(iter.hasNext())
		 {
			 System.out.println(iter.next()+" ");
		 }
	}

}
