import java.util.*;
public class HashSetCountry {
	 HashSet<String> h1 = new HashSet<String>();
	 
	HashSet<String> saveCountryNames(String CountryName)
	 {
		h1.add("India");
		 h1.add("Australia");
		String con=CountryName;
		 h1.add(con);
		 return h1;
	 }
	void getCountry(String CountryName)
	{
		String con=CountryName;
		for(String st: h1)
		{
			if(st.contentEquals(con))
				System.out.println(st);
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSetCountry hh= new HashSetCountry();
		 HashSet<String> h2 = new HashSet<String>();
		 h2= hh.saveCountryNames("France");
		 System.out.println(h2);
		 hh.getCountry("France");
	}

}
