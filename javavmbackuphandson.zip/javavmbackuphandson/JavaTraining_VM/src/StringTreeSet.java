import java.util.*;

public class StringTreeSet {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<String> ts1 = new TreeSet<>();
		ts1.add("Aa");
		ts1.add("Bb");
		ts1.add("Cc");
        ts1.add("Dd");
//	 List list = new ArrayList(ts1); Collections.sort(list,
//	 Collections.reverseOrder()); Set resultSet = new TreeSet(list);
//	 System.out.println(resultSet);

		TreeSet<String> rev = (TreeSet<String>) ((TreeSet<String>)ts1).descendingSet();
		for (String ch : rev)
			System.out.print(ch+" ");
		System.out.println("\n Iterator");
		Iterator<String> iter= ts1.iterator();
		 while(iter.hasNext())
		 {
			 System.out.print(iter.next()+" ");
		 }
		 System.out.println("\nenter str to check in set");
		 Scanner s= new Scanner(System.in);
		 String str= s.next();
		 for(String ss: ts1)
		 {
			 if(str.contentEquals(ss))
			 {
				 System.out.println("\nfound "+ss);
				 System.exit(0);
			 }
				 
		 }
		 System.out.println("Element not found");
	}

}
