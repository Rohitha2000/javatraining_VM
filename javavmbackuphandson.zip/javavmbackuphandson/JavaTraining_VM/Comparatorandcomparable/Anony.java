class Student
{  
     void record()
     {
    	 System.out.println("This is record method");
     }
} 
class Anony
{  
    public static void main(String args[])
    {  
        Student obj = new Student()
        {  
            void record()
            {
               System.out.println("This method is from anonymous class");
            }  
};  
  obj.record();  
 }  
} 