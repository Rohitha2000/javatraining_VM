package ComparatorEx;
import java.util.*;
public class EmpMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Employee> li= new ArrayList<Employee>();
		li.add(new Employee("Rohitha", 21, 25000));
		li.add(new Employee("Vaishnavi", 22, 15000));
		li.add(new Employee("Praveen", 20 , 20000));
		Comparator<Employee> com= new Comparator<Employee>()
				{
			       public int compare(Employee e1, Employee e2)
			       {
			    	   if(e1.getSalary() >= e2.getSalary())
			    		   return 1;
			    	   else
			    		   return -1;
			       }
				};
				Collections.sort(li, com);
				for(Employee e: li)
				{
					System.out.println(e);
				}

	}

}
