package BookManipulation;

public class Book {
private int bookno;
private String bookname;
private String author;
//Book()
//{
//	super();
//	this.bookno = bookno;
//	this.bookname = bookname;
//	this.author = author;
//}
Book(int bookno, String bookname, String author)
{
	super();
	this.bookno = bookno;
	this.bookname = bookname;
	this.author = author;
}
public int getBookno() {
	return bookno;
}
public void setBookno(int bookno) {
	this.bookno = bookno;
}
public String getBookname() {
	return bookname;
}
public void setBookname(String bookname) {
	this.bookname = bookname;
}
public String getAuthor() {
	return author;
}
public void setAuthor(String author) {
	this.author = author;
}


}
