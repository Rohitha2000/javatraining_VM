package BookManipulation;
import java.util.*;
public class Library {
	private ArrayList<Book> bookList = new  ArrayList<Book>();
	
	// constructor
	Library()
	{
		this.bookList= bookList;
	}
	
	
	// Getters and setters
	public ArrayList<Book> getBookList() {
		return bookList;
	}
	public void setBookList(ArrayList<Book> bookList) {
		this.bookList = bookList;
	}
	
	
	// adding object
	void addBook(Book obj)
	{
		bookList.add(obj);
	}
	
	
	// checking if empty
	boolean isEmpty()
	{
		return bookList.isEmpty();
	}
	
	
	// view books
	ArrayList<Book> viewAllBooks() 
	{
		return bookList;
	}
	
	
	// return books with same author
	ArrayList<Book> viewBooksByAuthor(String author )
	{
		ArrayList<Book> bk= new ArrayList<Book>();
		for(Book b: bookList)
		{
			if(b.getAuthor().equals(author))
			{
				bk.add(b);
			}
		}
		return bk;
	}
	
	
	// counting books
	int countnoofbook(String bname)
	{
		int count=0;
		for(Book b: bookList)
		{
			if(b.getBookname().equals(bname))
			{
				count++;
			}
		}
		return count;
	}
}
