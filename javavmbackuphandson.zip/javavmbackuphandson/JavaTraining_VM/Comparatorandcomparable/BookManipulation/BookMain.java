package BookManipulation;

import java.util.*;

public class BookMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = 1;
		
	//	Book bb = new Book();
		ArrayList<Book> bklist = new ArrayList<Book>();
		Library lib = new Library();
		while (i == 1) {

			System.out.println("1. Add Book");
			System.out.println("2. Display all Book Details");
			System.out.println("3. Search Book by Author");
			System.out.println("4. Count Number of Books- by book name");
			System.out.println("5 Exit");
			Scanner s = new Scanner(System.in);
			int num, number;
			String bkname, bkauthor;
			System.out.println("Enter Choice");
			num = s.nextInt();
			
			if (num == 1) {
				System.out.println("Enter Book Number");
				number= s.nextInt();
				s.nextLine();
				System.out.println("Enter Book Name");
				
				bkname=s.nextLine();
				
				System.out.println("Enter Author");
				
				bkauthor= s.nextLine();
				//System.out.println();
				Book bb= new Book(number, bkname, bkauthor);
				lib.addBook(bb);

			} else if (num == 2) {
				ArrayList<Book>bst = lib.viewAllBooks();
				  if(bst.isEmpty())
	                 {
	                     System.out.println("The list is empty");
	                     continue;
	                 }
				for (Book b1 : bst) {
					System.out.println("Book Number:  " + b1.getBookno());
					System.out.println("Book Name:  " + b1.getBookname());
					System.out.println("Book Author" + b1.getAuthor());
				}
			} else if (num == 3) {
				System.out.println("Enter to search book by Author Name ");
				String au;
				s.nextLine();
				au = s.nextLine();
				
				ArrayList<Book> b2 = lib.viewBooksByAuthor(au);
				  if(b2.isEmpty()){
	                     System.out.println("None of the book published by the author "+au);
	                     continue;
	                 }
				for (Book bs : b2) {
					System.out.println("Book Number:  " + bs.getBookno());
					System.out.println("Book Name:  " + bs.getBookname());
					System.out.println("Book Author" + bs.getAuthor());
				}
			} else if (num == 4) {
				System.out.println("Enter to count No of Books by Book name");
				String nm;
				s.nextLine();
				nm = s.nextLine();
				System.out.println("Number of Books by name: " + nm + " are: " + lib.countnoofbook(nm));
			} else if (num == 5) {
				System.exit(0);
			}
		}

	}

}
