
import java.util.*;
public class StringConcatenation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   String name, fname;
   Scanner s= new Scanner(System.in);
   System.out.println("Inmate's Name: ");
   name= s.nextLine();
   System.out.println("Inmate's father name: ");
   fname= s.nextLine();
   char[] inmate= name.toCharArray();
   for(char ch: inmate)
   {
	   if(Character.isDigit(ch))
	   {
		   System.out.println("Invalid");
		   return;
	   }
   }
	
	char[] inmatefather= fname.toCharArray();
	  for(char ch1: inmatefather)
	   {
		   if(Character.isDigit(ch1))
		   {
			   System.out.println("Invalid");
			   return;
		   }
	   }
   System.out.println(name.toUpperCase()+" "+ fname.toUpperCase()+" ");
}
}
