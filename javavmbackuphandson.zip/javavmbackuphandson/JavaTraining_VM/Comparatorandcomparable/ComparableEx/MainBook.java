package ComparableEx;
import java.util.*;
public class MainBook {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    List<Book> book= new ArrayList<Book>();
    book.add(new Book("metamorphosis", 87, "kafka"));
    book.add(new Book("Psychology of money", 346,"Franzkl"));
    book.add(new Book("One Indian Girl", 499,"Chetan Bhagat"));
    Collections.sort(book);
   for(Book bk: book)
    {
    	System.out.println(bk);
    }
	}

}
