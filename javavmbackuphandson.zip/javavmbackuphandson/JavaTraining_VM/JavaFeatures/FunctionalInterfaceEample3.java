interface Doable{



  default void doIt(){

    System.out.println("Do it now");

  }

}

@FunctionalInterface

interface Sayable extends Doable{

  void say(String msg); // abstract method

}

public class FunctionalInterfaceEample3 implements Sayable{

  public void say(String msg){

    System.out.println(msg);

  }

  public static void main(String[] args) {

    FunctionalInterfaceEample3 fie = new FunctionalInterfaceEample3();

    fie.say("Hello there");

    fie.doIt();

  }

}

