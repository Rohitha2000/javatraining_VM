import java.time.LocalDate;

public class IsLeapYear {

 public static void main(String[] args) {

  LocalDate date1 = LocalDate.of(2017, 1, 13);

  System.out.println("Is "+date1.getYear()+ " a leap year? "+date1.isLeapYear());

  LocalDate date2 = LocalDate.of(2016, 9, 23);

  System.out.println("Is "+date2.getYear()+ " a leap year? "+date2.isLeapYear());

 }

}