import java.util.Scanner;
import java.lang.*;
public class ReplaceString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str1, str2;
	      Scanner s= new Scanner(System.in);
	      System.out.println("enter first string");
	      str1= s.next();
	      System.out.println("enter second string");
	      str2= s.next();
	     

	    int  len1= str1.length();
	    int  len2= str2.length();
	   
	  str1= str1.replace(str2," ");
	   char[] ch= str1.toCharArray();
	   for(int j=0;j< str1.length(); j++)
	   {
		   if(ch[j]== ' ')
		   {
			  // System.out.print("Hello");
			   
			   System.out.print(ch[j-1]);
			   System.out.print(ch[j+1]);
			   j++;
		   }
	   }
	}

}
