import java.util.*;
import java.lang.*;
public class Removestar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s= new Scanner(System.in);
		String s1;
		int c=0;
		s1= s.next();
		char[] ch= s1.toCharArray();
		 StringBuffer sb = new StringBuffer(s1);
		int len= s1.length();
		for(int i=0;i<len;i++)
		{
			if(ch[i]== '*')
				c=i;
		}
		char c1= ch[c-1];
		
		System.out.println(sb.delete(c-1,c+2));
		
//		for(int j= c-1;j<c+2;j++)
//		{
//			
//		}
		
	}

}
