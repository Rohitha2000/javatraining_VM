import java.util.*;
interface Playable
{
	void play();
}
abstract class Runn implements Playable
{
	void runn()
	{
		
	}
}
public class Abstractclass {

	public static void main(String[] args) {

	}

}
