import java.util.Arrays;
import java.util.Scanner;

public class ArrayMax2min2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s= new Scanner(System.in);
		System.out.println("enter size");
		int num= s.nextInt();
		int sum=0, avg;
		int arr[]= new int[num];
		for(int i=0;i<num;i++)
		{
			arr[i]= s.nextInt();
		}
		int min=arr[0], max=arr[0];
	Arrays.sort(arr);
	System.out.println("1st smallest:  "+ arr[0]);
	System.out.println("2st smallest:  "+ arr[1]);
	System.out.println("1st largest :  "+ arr[num-1]);
	System.out.println("2st largest :  "+ arr[num-2]);



	}

}
