import java.time.*;

public class DateAtTime {

 public static void main(String[] args) {

 LocalDate date = LocalDate.of(2021, 7, 22);

   LocalDateTime datetime = date.atTime(1,50,9);

   System.out.println(datetime);
   LocalTime time = LocalTime.now();

   System.out.println(time);
 }

}

