import java.util.Scanner;
import java.util.*;
public class FirstLastX {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s= new Scanner(System.in);
		String s1;
		s1= s.next();
		int len= s1.length();
		if(s1.charAt(0) == 'x' && s1.charAt(len-1)== 'x' )
		{
			System.out.println(s1.substring(1,len-1));
		}
		else
		{
			System.out.println(s1);
		}
	}

}
