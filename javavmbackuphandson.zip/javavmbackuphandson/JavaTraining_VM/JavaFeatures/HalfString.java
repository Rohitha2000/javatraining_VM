import java.util.*;
public class HalfString {
public static void main(String[] args) {
	Scanner s= new Scanner(System.in);
	String s1;
	s1= s.next();
	int len= s1.length();
	System.out.println(len);
	if(len%2 == 0)
	{
		System.out.println(s1.substring(0,len/2));
	}
	else
	{
		System.out.println("null");
	}
}
}
