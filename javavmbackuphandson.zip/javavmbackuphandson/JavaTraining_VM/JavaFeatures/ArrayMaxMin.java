import java.util.*;
public class ArrayMaxMin {
public static void main(String[] args) {
	Scanner s= new Scanner(System.in);
	System.out.println("enter size");
	int num= s.nextInt();
	int sum=0, avg;
	int arr[]= new int[num];
	for(int i=0;i<num;i++)
	{
		arr[i]= s.nextInt();
	}
	int min=arr[0], max=arr[0];
	for(int j=1;j<num;j++)
	{
		
		if(arr[j]< min)
		{
			min= arr[j];
		}
		if(arr[j]> max)
		{
			max= arr[j];
		}
	}
	System.out.println("Min: "+min+" Max: "+max);
}
}
