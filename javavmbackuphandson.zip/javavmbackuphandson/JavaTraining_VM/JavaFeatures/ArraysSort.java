import java.util.*;
import java.util.Scanner;

public class ArraysSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s= new Scanner(System.in);
		System.out.println("enter size");
		int num= s.nextInt();
		int sum=0, avg;
		int arr[]= new int[num];
		System.out.println("Enter elements");
		for(int i=0;i<num;i++)
		{
			arr[i]= s.nextInt();
		}
		Arrays.sort(arr);
		System.out.println("Array after sorting");
		
		for(int i=0;i<num;i++)
		{
			System.out.print(arr[i]+" ");
		}
	}

}
