import java.util.*;
public class FirstandLastRemoveString {
public static void main(String[] args) {
	Scanner s= new Scanner(System.in);
	String s1;
	s1= s.next();
	int len= s1.length();
	String str= s1.substring(1,len-1);
	System.out.println(str);
}
}
