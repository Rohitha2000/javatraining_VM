interface Messageable{

  Message getMessage(String msg);

}

class Message{

  Message(String msg){

    System.out.print(msg);

  }

}

public class ConstructorReference {

  public static void main(String[] args) {

    Messageable ob = Message::new;

     ob.getMessage("Hello");

  }

}