import java.util.*;
import java.lang.*;
public class StringAlternateoutput {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str1, str2;
		Scanner s = new Scanner(System.in);
		System.out.println("enter first string");
		str1 = s.next();
		System.out.println("enter second string");
		str2 = s.next();
		int len1 = str1.length();
		int len2 = str2.length();
		char[] ch1= str1.toCharArray();
		char[] ch2= str2.toCharArray();
	     String str;
	     if(len1>= len2)
	     {
	    	 for(int i=0;i<len1;i++)
	    	 {
	    		System.out.print(ch1[i]);
	    		System.out.print(ch2[i]);
	    	 }
	     }

	}

}
