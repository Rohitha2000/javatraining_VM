import java.util.*;
public class SumAvgArray {
public static void main(String[] args) {
	Scanner s= new Scanner(System.in);
	System.out.println("enter size");
	int num= s.nextInt();
	int sum=0, avg;
	int arr[]= new int[num];
	for(int i=0;i<num;i++)
	{
		arr[i]= s.nextInt();
	}
	for(int j=0;j<num;j++)
	{
		sum= sum+arr[j];
	}
	avg=sum/num;
	System.out.println("Sum:  "+sum);
	System.out.println("Average:  "+avg);
}
}
