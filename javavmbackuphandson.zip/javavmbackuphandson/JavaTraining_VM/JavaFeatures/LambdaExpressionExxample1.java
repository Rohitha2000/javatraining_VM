import java.util.*;

interface Drawable{

  public int draw(int a, int b);

}

public class LambdaExpressionExxample1 {

  public static void main(String[] args) {

    int width=10;

    Drawable ob=(a,b)->{

     System.out.println("width= "+width);
     return a+b;

     };

     System.out.println(ob.draw(23,77));
     
     
     List<String> list=new ArrayList<>();

     list.add("ankit");

     list.add("mayank");

     list.add("irfan");

     list.add("jai");

     list.forEach( (name)->System.out.println(name) );

  }

}

