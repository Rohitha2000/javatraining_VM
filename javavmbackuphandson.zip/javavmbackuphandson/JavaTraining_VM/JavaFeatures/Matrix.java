
public class Matrix {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[][] arr= new int[2][2];
		
		  for(int i=0; i<2; ++i)
		    {
		        for(int j=0; j<2; ++j)
		        {
		            arr[i][j]=Integer.parseInt(args[2*i+j]);
		        }
		    }
		  for(int i=0;i<2;i++)
		  {
			  for(int j=0;j<2;j++)
			  {
				  System.out.print(arr[i][j]+" ");
			  }
			  System.out.println("\n");
		  }
		  System.out.println("after reversing matrix");
		  for(int i=1; i>=0; --i)
		  {
		       for(int j=1; j>=0; --j)
		       { 
		            System.out.print(arr[i][j]+" ");
		       }
		       System.out.println("\n");
		  }
	}

}
