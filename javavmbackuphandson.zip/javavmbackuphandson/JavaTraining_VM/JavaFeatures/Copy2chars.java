import java.util.*;
public class Copy2chars {

	public static void main(String[] args) {
		// TODO Auto-generated method stu
		Scanner s= new Scanner(System.in);
		String str;
		str= s.next();
		String str1= str.substring(0,2);
		//System.out.println(str1);
		for(int i=0;i<str.length();i++)
			System.out.print(str1);
			
	}

}
