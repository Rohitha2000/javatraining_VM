import java.util.*;

public class StringLast3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s= new Scanner(System.in);
		String str;
		str= s.next();
		int n;
		n= s.nextInt();
		int len= str.length();
		String s3= str.substring(len-3,len);
		for(int i=0;i<n;i++)
		{
			System.out.print(s3);
		}
				//value
	}

}
