import java.util.*;
public class ShortLongShort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      String str1, str2;
      Scanner s= new Scanner(System.in);
      System.out.println("enter first string");
      str1= s.next();
      System.out.println("enter second string");
      str2= s.next();
    int  len1= str1.length();
    int  len2= str2.length();
    String st;
    if(len1 > len2)
    {
    	st= str2+str1+str2;
    	System.out.println(st);
    }
    else if(len1< len2)
    {
    	st= str1+str2+str1;
    	System.out.println(st);
    }
      
	}

}
