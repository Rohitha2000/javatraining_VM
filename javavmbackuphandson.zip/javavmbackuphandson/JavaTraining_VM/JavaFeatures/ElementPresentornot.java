import java.util.Scanner;
import java.util.*;

public class ElementPresentornot {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s= new Scanner(System.in);
		System.out.println("enter size");
		int num= s.nextInt();
		int sum=0, avg;
		int arr[]= new int[num];
		System.out.println("Enter elements");
		for(int i=0;i<num;i++)
		{
			arr[i]= s.nextInt();
		}
		int index, ele;
		System.out.println("Enter element to find in the array");
		ele= s.nextInt();
		for(int j=0;j<num;j++)
		{
			if(ele == arr[j])
			{
				System.out.println("The Element "+arr[j]+" is fount at position "+j);
				index=j;
				System.exit(0);
			}
			else if(j== num-1)
			{
				index=-1;
				System.out.println("The Element "+arr[j]+" is not found ");
			}
		}
		
		
	}

}
