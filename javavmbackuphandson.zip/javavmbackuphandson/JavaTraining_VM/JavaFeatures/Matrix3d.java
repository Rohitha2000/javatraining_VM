
public class Matrix3d {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int[][]arr= new int [3][3];
for(int i=0;i< 3;i++)
{
	for(int j=0;j<3;j++)
	{
		
			arr[i][j]= Integer.parseInt(args[3*i+j]);
		
	}
	
}
int grt= arr[0][0];
for(int i=0;i<3;i++)
{
	  for(int j=0;j<3;j++)
	  {
		  System.out.print(arr[i][j]+" ");
		  if(arr[i][j]> grt)
			  grt= arr[i][j];
	  }
	  System.out.println("\n");
}
System.out.println("greatest:  "+grt);
	}

}
