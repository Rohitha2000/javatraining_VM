import java.util.*;

public class Remove67Array {

	static void conditionalSum(int l[], int a, int b) {

		int sum = 0;
		boolean add = true;
		
		for (int i=0; i<l.length; i++) {

			if (l[i] != a && add == true)

				sum = sum + l[i];
			
			else if (l[i] == a)
				add = false;

			else if (l[i] == b)
				add = true;

		}

		System.out.println(sum);

	}

	public static void main(String[] args) {

		Scanner s= new Scanner(System.in);
		System.out.println("enter size");
		int num= s.nextInt();
		
		int arr[]= new int[num];
		System.out.println("Enter elements");
		for(int i=0;i<num;i++)
		{
			arr[i]= s.nextInt();
		}
		int a = 6;
		int b = 7;
		conditionalSum(arr,a,b);
		

        }
}
