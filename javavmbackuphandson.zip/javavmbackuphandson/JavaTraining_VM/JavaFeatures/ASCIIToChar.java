import java.util.*;
public class ASCIIToChar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s= new Scanner(System.in);
		System.out.println("enter size");
		int num= s.nextInt();
		int sum=0, avg;
		int arr[]= new int[num];
		System.out.println("Enter elements");
		for(int i=0;i<num;i++)
		{
			arr[i]= s.nextInt();
		}
		for(int i=0;i<num;i++)
		{
			System.out.println((char)arr[i]);
		}
	}

}
