import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

class MyTh extends Thread
{
	static Thread mt;
	public void run()
	{
		int capacity = 10;
		BlockingQueue<String> bb = new LinkedBlockingQueue<String>(capacity);
		bb.add("rohi");
		bb.add("vini");
		bb.add("beagle");
		bb.add("cooper");
		System.out.println(bb);
		System.out.println("child");
	try
	{
		mt.join();
		Thread.sleep(3000);
		
	}catch(InterruptedException e) {System.out.println(e);}
	
	
	
	}
}
public class ThreadLinkedBlockingQueue {
	

	public static void main(String[] args) throws InterruptedException{
		// TODO Auto-generated method stub
		
		MyTh.mt=  Thread.currentThread();
		MyTh cc = new MyTh();
			
		cc.start();
	
		System.out.println("main thread");
		
		

	}

}
