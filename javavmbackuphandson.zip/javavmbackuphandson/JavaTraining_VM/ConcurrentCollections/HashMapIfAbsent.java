import java.util.*;
import java.util.concurrent.*; 
public class HashMapIfAbsent {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ConcurrentHashMap<String, Integer> hmap   = new ConcurrentHashMap<>();   
    hmap.put("rohi", 10);   
    hmap.put("vaishu", 15);   
    hmap.put("vini", 30);   
   
    System.out.println("HashMap values :\n " + hmap.toString());    
    hmap.computeIfAbsent("oswa", o -> 55);   
    hmap.computeIfAbsent("danny", o -> 100);   
    System.out.println("New HashMap after computeIfAbsent :\n "+ hmap); 
    
    
    // 2nd program
    System.out.println("2th prog \n \n");
    System.out.println("is rohi contains? "+ hmap.contains(10)+"\n");
    
    //3rd 
    System.out.println("3th prog \n \n");
    hmap.compute("rohi", (key, val)-> val+567);
    System.out.println("Compute: "+hmap.get("rohi"));
    
    //4th prog
    System.out.println("4th prog \n \n");
    hmap.computeIfAbsent("arti",a->10);
    System.out.println(hmap);
    
    
    //5th prog
    System.out.println("5th prog \n \n");
    System.out.println("is vini contains as key in hmap? "+ hmap.containsKey("vini"));
    
    //6th prog
    System.out.println("6th prog \n \n");
    ConcurrentHashMap<String, Integer> hmap1   = new ConcurrentHashMap<>();
    hmap1.put("vini", 30);
    ConcurrentHashMap<String, Integer> hmap2   = new ConcurrentHashMap<>();
    hmap1.put("vini", 30);
    System.out.println("Are maps equal (using equals):" + hmap1.equals(hmap2));
    
    //7th prog
    System.out.println("7th prog \n \n");
    System.out.println("hashcode :" +hmap.hashCode());  
    
    //8th prog
    System.out.println("8th prog \n \n");
    System.out.println("Mapping count:  "+hmap.mappingCount());
    
	}
	
	

}
