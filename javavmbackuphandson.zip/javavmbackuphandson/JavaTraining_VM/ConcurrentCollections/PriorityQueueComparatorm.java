

		import java.util.Collections;  
		import java.util.Comparator;  
		import java.util.List;  
		import java.util.PriorityQueue;  
		  
		 class Student4 {  
		public String name;  
		public int marks;  
		  
		Student4(String name,int marks){  
		  
		this.name=name;  
		this.marks=marks;  
		    }  
		public String toString(){  
		  
		return this.name+" got "+ this.marks+" marks.";  
		    }  
		}       
		class sort implements Comparator<Student4>{  
		  
		@Override  
		  
		public int compare(Student4 a, Student4 b) {  
		if(a.marks<b.marks)  
		return 1;  
		else if(a.marks>b.marks)  
		return-1;  
		return 0;  
		         }  
		     }  
		  
		public class PriorityQueueComparatorm {  
		  
		public static void main(String[] args) {  
		  
		        Student4 student1 = new Student4("Ram", 98);  
		        Student4 student2 = new Student4("Rahul", 19);  
		        Student4 student3 = new Student4("Himanshu", 78);  
		        Student4 student4 = new Student4("Vini", 18);  
		  
		PriorityQueue<Student4>Pqueue = new PriorityQueue<Student4>(5,new sort());  
		  
		Pqueue.add(student1);  
		Pqueue.add(student2);  
		Pqueue.add(student3);  
		Pqueue.add(student4);  
		  
		for(Student4 xyz:Pqueue){  
		  
		System.out.println(xyz);  
		        }  
		         Comparator comp =Pqueue.comparator();  
		  
		System.out.println("\nComparator value is "+comp);  
		    }  
		}  