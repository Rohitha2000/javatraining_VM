import java.util.*;
import java.util.concurrent.*;
public class ArrayBlockingQueue1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//14th program
        int capacity=10;
	ArrayBlockingQueue<Integer> abq = new ArrayBlockingQueue<Integer>(capacity);
		
		//adding
		abq.add(10);
        abq.add(20);
        abq.add(30);
        abq.add(40);
        System.out.println(abq);
        
        //remove
        abq.remove(10);
        System.out.println(abq);
        
        //iterate
        for(int i:abq)
        	System.out.println(i);
        
        //accessing
        System.out.println("accessing:  "+abq.peek());
		
		
	}

}
