import java.util.*;
import java.util.concurrent.*;
public class LinkedBlockingQueue1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int capacity= 10;
		BlockingQueue<String> bb = new LinkedBlockingQueue<String>(capacity);
		bb.add("Block");
		System.out.println(bb.size()+ bb.remainingCapacity());
		bb.add("linking");
		bb.add("pizza");
		bb.add("burger");
		bb.add("phone");
		System.out.println(bb);
		
		//10th program
		System.out.println("\n 10th program \n");
		bb.remove("linking");
		bb.remove("phone");
		System.out.println(bb);
		
		//11th program
		System.out.println("\n 11th program \n");
		bb.add("phone");
		System.out.println("Iteration");
		for(String st: bb)
		{
			System.out.println(st);
		}
		
		
		//12th program
		System.out.println("\n 12th program \n");
		System.out.println(bb.element());
		
		//13th program
		System.out.println("\n 13th program \n");
		System.out.println("bb head: "+bb.peek());
		
		//14th program
		
		
	}

}
