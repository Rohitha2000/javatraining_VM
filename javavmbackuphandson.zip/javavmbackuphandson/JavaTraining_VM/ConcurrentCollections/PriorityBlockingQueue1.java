import java.util.*;
import java.util.concurrent.*;
public class PriorityBlockingQueue1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PriorityBlockingQueue<Integer> pb = new PriorityBlockingQueue<Integer>();
// 18th prog
    // add  numbers
    pb.add(465);
    pb.add(233);
    pb.add(321);
    pb.add(444);
    pb.add(555);
     System.out.println(pb);
     
     //removing
     pb.remove(321);
     pb.remove(444);
     System.out.println(pb);
     
     // iterate
     Iterator k = pb.iterator();
     while (k.hasNext()) {
         System.out.println(k.next());
     }
     
     //accessing
     System.out.println("Head: "+pb.peek());
     
     
     
     //16th program
     System.out.println("\n 16th prog \n");
     Vector<Integer> v = new Vector<Integer>();
     v.addElement(11);
     v.addElement(22);
     v.addElement(33);
     v.addElement(44);
     v.addElement(55);

    
     PriorityBlockingQueue<Integer> pq
         = new PriorityBlockingQueue<Integer>(v);

     // print queue
     System.out.println("PriorityBlockingQueue:" + pq);
     
     
     //17th prog
     int capacity= 12;
     PriorityBlockingQueue<Integer> p1  = new PriorityBlockingQueue<Integer>(capacity, Comparator.reverseOrder());

      // add  numbers
      p1.add(11);
      p1.add(22);
      p1.add(33);

      // print queue
      System.out.println("PriorityBlockingQueue:" + p1);
	}

}
