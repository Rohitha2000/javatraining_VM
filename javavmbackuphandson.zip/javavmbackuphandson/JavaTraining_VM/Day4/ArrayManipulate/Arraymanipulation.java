package ArrayManipulate;
import java.util.*;
public class Arraymanipulation {
	public static String getPriceDetails() 
	{
		int num,ind,arr[];
		Scanner s= new Scanner(System.in);
		System.out.println("enter no of elements in array");
		num= s.nextInt();
		arr= new int[num];
		System.out.println("enter elements of array");
		for(int i=0;i<num;i++)
		{
			arr[i]= s.nextInt();
		}
		System.out.println("enter the index to show the element");
		ind= s.nextInt();
		String str= "The array element is "+ arr[ind];
		return str;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
		{
		   System.out.println(getPriceDetails());
		}
		catch(ArrayIndexOutOfBoundsException e)
		{System.out.println("Array index is out of range"+e);}
		catch(InputMismatchException ee)
		{
			System.out.println("Input was not in the correct format"+ee);}
		}
	}


