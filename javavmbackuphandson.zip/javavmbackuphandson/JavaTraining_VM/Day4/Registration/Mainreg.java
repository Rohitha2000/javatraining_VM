package Registration;

import java.util.*;

class InvalidSalaryException extends Exception {
	InvalidSalaryException(String sal) {
		super(sal);
	}
}

public class Mainreg {
	public static Candidate getCandidateDetails() throws InvalidSalaryException {
		String name, gender;
		double salary;
		Candidate cd = new Candidate();
		Scanner s = new Scanner(System.in);
		System.out.println("Enter Name");
		name = s.nextLine();
		cd.setName(name);
		System.out.println("Enter Gender");
		gender = s.next();
		cd.setName(gender);
		System.out.println("Enter expected salary");
		salary = s.nextDouble();
		cd.setExpectedSalary(salary);
		if (cd.getExpectedSalary() < 10000) {
			throw new InvalidSalaryException("Registration Failed. Salary cannot be less than 10000");
		} else {
			System.out.println("Registration Sucessful");
		}
		return cd;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Candidate res=
		try {
			getCandidateDetails();
		} catch (Exception e) {
			System.out.println("Exception occured: " + e);

		}
		System.out.println("Rest of the code");

	}

}
