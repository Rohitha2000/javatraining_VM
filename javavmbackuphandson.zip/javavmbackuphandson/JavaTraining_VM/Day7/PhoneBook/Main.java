package PhoneBook;

import java.util.*;

public class Main {
	public static void main(String args[]) {
		Scanner s = new Scanner(System.in);
		int i = 0, num;
		PhoneBook ph = new PhoneBook();
		
		
		while (i == 0) {
			System.out.println("Menu");
			System.out.println("1. Add Contact");
			System.out.println("2. Display All Contacts");
			System.out.println("3. Search contact by phone");
			System.out.println("4. Exit");
			System.out.println("Enter your choice");
			num = s.nextInt();
			if (num == 1) {
				Contact cn = new Contact();
				System.out.println("Add Contact: ");
				System.out.println("Enter First Name");
				cn.setFirstName(s.next());
				System.out.println("Enter Last name");
				cn.setLastName(s.next());
				System.out.println("Enter Phone number");
				cn.setPhoneNumber(s.nextLong());
				System.out.println("Enter Email id");
				cn.setEmailId(s.next());
                ph.addContact(cn);
                
			}
			else if(num==2)
			{
				System.out.println("The contacts in the List are:");
				List<Contact>obj= ph.viewAllContacts();
				for(Contact temp: obj)
				{
					System.out.println("First Name:"+temp.getFirstName());
                    System.out.println("Last Name:"+temp.getLastName());
                    System.out.println("Phone No.:"+temp.getPhoneNumber());
                    System.out.println("Email:"+temp.getEmailId());
				}
				
			}
			else if(num== 3)
			{
				System.out.println("Enter contact number");
				Long p= s.nextLong();
				Contact c1= ph.viewContactGivenPhone(p);
				 System.out.println("The contact is:");
                 System.out.println("First Name:"+c1.getFirstName());
                 System.out.println("Last Name:"+c1.getLastName());
                 System.out.println("Phone No.:"+c1.getPhoneNumber());
                 System.out.println("Email:"+c1.getEmailId());
                
			}
			else if(num==4)
			{
				System.exit(0);
			}
		}
	}
}