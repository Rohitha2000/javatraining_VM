package PhoneBook;
import java.util.*;
public class PhoneBook {
	  private List<Contact> phoneBook=new ArrayList<Contact>();
	  PhoneBook()
	  {
		  this.phoneBook = phoneBook;
	  }

	public List<Contact> getPhoneBook() {
		return phoneBook;
	}

	public void setPhoneBook(List<Contact> phoneBook) {
		this.phoneBook = phoneBook;
	}
	   
	
	
	
	public void addContact(Contact contactObj)
	{
		phoneBook.add(contactObj);
	}
	
	
	
	public List<Contact> viewAllContacts()
	{
		return phoneBook;
	}
	
	
	 public Contact viewContactGivenPhone(long phoneNumber)
	    {
	       Contact cn= new Contact();
	       for(Contact obj: phoneBook) {
	       if(obj.getPhoneNumber()== phoneNumber)
	       {
	    	   cn= obj;
	    	   return cn;
	       }
	    }
	       return cn;
	    }
	 
	 
	 
	  public boolean removeContact(long phoneNumber)
	    {
	        boolean f=false;
	        for(Contact obj:phoneBook)
	        {
	            if(obj.getPhoneNumber()==phoneNumber)
	            {
	                f=true;
	                phoneBook.remove(obj);
	                break;
	            }
	        }
	        return f;
	    }
}
