package AllCollections;
import java.util.*;
public class Treeset1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Set<String> ts1 = new TreeSet<>();
		 
	        // Elements are added using add() method
	        ts1.add("Aa");
	        ts1.add("Bb");
	        ts1.add("Cc");
	 
	        // Duplicates will not get insert
	        ts1.add("Hc");
	        ts1.add("Dd");
	        System.out.println(ts1);
	        // Elements get stored in default natural
	        // Sorting Order(Ascending)
	        ts1.remove("Bb");
	        System.out.println("Removed B----  "+ts1);
	        
	}

}
