package AllCollections;
import java.util.*;

public class MapDemo {

  public static void main(String a[])

  {

   Map<Integer,String> ob=new HashMap<>();

   //Map<Integer,String> ob=new LinkedHashMap<>();

   //Map<Integer,String> ob=new TreeMap<>();

     //

    ob.put(80,"vijay"); // key should not be duplicate value & value can be duplicate

       // key and value can be null

    ob.put(20,"chandra");

    ob.put(30,"sekhar");

    ob.put(5,"vijay");

    // ob.put(10,"hfdkjf");

    ob.put(10, "Hello");

    Set s=ob.entrySet(); // get key and values

    Iterator it=s.iterator();

    while(it.hasNext())

    {

     Object o=it.next();

      System.out.println(o);

    }

    /*Set<Map.Entry<Integer,String>> map= ob.entrySet();//Entry is the inner interface inside Map just like inner class

    for(Map.Entry<Integer, String> it: map)

    {

     System.out.println(it.getKey()+" "+it.getValue());

    }*/

  /* Set <Integer>s1= ob.keySet(); // only keys

    Iterator <Integer>it1=s1.iterator();

    while(it1.hasNext())

    {

   int o= it1.next(); //Integer o= it1.next();

      System.out.println(o+" "+ob.get(o));

    }*/

  }

}























