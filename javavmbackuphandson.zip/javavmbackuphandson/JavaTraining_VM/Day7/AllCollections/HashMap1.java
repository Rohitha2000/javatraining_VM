package AllCollections;
import java.util.*;
public class HashMap1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 HashMap<String, String> capitalCities = new HashMap<String, String>();

		    // Add keys and values (Country, City)
		    capitalCities.put("England", "London");
		    capitalCities.put("Germany", "Berlin");
		    capitalCities.put("Norway", "Oslo");
		    capitalCities.put("USA", "Washington DC");
		    System.out.println(capitalCities);
		    
		    System.out.println(capitalCities.get("England"));
		    
		 // Print keys
		    for (String i : capitalCities.keySet()) {
		      System.out.println(i);
		    }
		    
		    
		    //values
		    for (String i : capitalCities.values()) {
		    	  System.out.println(i);
		    	}
		    capitalCities.remove("England");
		    System.out.println("removed england:--- "+capitalCities);
	}

}
