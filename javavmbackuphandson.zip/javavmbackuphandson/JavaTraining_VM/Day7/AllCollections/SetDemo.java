package AllCollections;
import java.util.*;
public class SetDemo {
  public static void main(String a[])
  {
   //Set ob=new HashSet();
   //Set ob=new LinkedHashSet();
   Set ob=new TreeSet();
    ob.add(89);
    //ob.add("Vijay");
    boolean v=ob.add(55);
    ob.add(22);
    boolean x= ob.add(89);
    System.out.println(v+" "+ob.size()+ " "+x);
    Iterator it=ob.iterator();
    while(it.hasNext())
    {
     Object e=it.next();
     System.out.println(e);
    }
  } 
  }