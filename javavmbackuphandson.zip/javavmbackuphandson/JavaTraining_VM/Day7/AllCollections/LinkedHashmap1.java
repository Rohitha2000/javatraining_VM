package AllCollections;
import java.util.*;
public class LinkedHashmap1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedHashMap<Integer,String> hm=new LinkedHashMap<Integer,String>();  
		  
		  hm.put(100,"Amit");  
		  hm.put(101,"Vijay");  
		  hm.put(102,"Rahul");  
		  hm.put(111,"Rohi");
		  hm.put(345,"vini");
		  System.out.println("keys:  "+hm.keySet());
		  System.out.println("values:  "+hm.values());
		  System.out.println("Key- value pairs:  "+hm.entrySet());
		  
		  hm.remove(102);
		  System.out.println("removed 102- rahul "+hm);
		  for(Map.Entry m:hm.entrySet()){  
			   System.out.println(m.getKey()+" "+m.getValue());  
			  }  
	}

}
