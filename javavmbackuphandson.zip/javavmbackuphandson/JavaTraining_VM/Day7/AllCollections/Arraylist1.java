package AllCollections;
import java.util.*;
public class Arraylist1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> list=new ArrayList<String>();    
	      list.add("Mango");  
	      list.add("Apple");    
	      list.add("Banana");    
	      list.add("Grapes");    
	      list.add("Grapes"); 
	      list.add("Apple");
	      System.out.println(list);  
	      System.out.println(list.get(2));
	      
	      
	      list.set(0,"Guava");
	      System.out.println(list);
	      
	      list.remove("Banana");
	      System.out.println(list);
	      
	      list.clear();
	      System.out.println(list);
	      
	}

}
