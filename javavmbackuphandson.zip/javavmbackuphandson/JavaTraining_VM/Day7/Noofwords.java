
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Scanner;
public class Noofwords{
	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Scanner s= new Scanner(System.in);
    int count=0, uc=0;
    String str;
    System.out.println("Enter Student's Article");
    str= s.nextLine();
    
    // remove punctuations
    str = str.replaceAll("\\p{Punct}",""); 
    
    // splitting by whitespaces
    String[] words= str.split("\\s+");
    
    //Lowercase
    for(int i=0; i<words.length;i++)
    {
    	words[i]= words[i].toLowerCase();
    }
    
    //counting no of words
    for(String w: words)
    {
    	count++;
    	//System.out.println(w);
    }
    System.out.println("No of words are:  "+count);
  
    for(String w: words)
    {
    	//count++;
    	System.out.println(w);
    }
    HashSet<String> set = new HashSet<>(Arrays.asList(words));
    for(String st: set)
    {
    	uc++;
    }
    System.out.println("No of Unique words: "+uc);
    ArrayList<String> arr= new ArrayList<>(set);
    Collections.sort(arr);
    int m=0;
    for(String a: arr)
    {
    	m++;
    	System.out.println(m+". "+a);
    }
    
    
    
    
	}
	
}
