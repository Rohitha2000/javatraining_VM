package Dividetwonumbers;
import java.util.*;
public class Maindivide {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num1, num2;
		Scanner s= new Scanner(System.in);
		System.out.println("Enter the numbers");
		num1= s.nextInt();
		num2= s.nextInt();
		String str1= " Thanks for using the application.";
		String str2="Division by zero is not possible.";
		Division d= new Division();
		
		try
		{
			d.divideTwoNumbers(num1, num2);
		}
		catch(Exception e)
		{
			System.out.println(str2+str1);
		}
		System.out.println(d.divideTwoNumbers(num1, num2)+str1);
			//System.out.println(d.divideTwoNumbers(num1, num2)+str1);
		

	}

}
