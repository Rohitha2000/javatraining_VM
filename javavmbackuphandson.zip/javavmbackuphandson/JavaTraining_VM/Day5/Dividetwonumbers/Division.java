package Dividetwonumbers;

public class Division {
	public String divideTwoNumbers(int number1,int number2) 
	{
		int res= number1/number2;
		String str="";
		if(res != 0)
		{
			str= "The number is "+number1+"/"+ number2+".";
			return str;
		}
		return str;
	}
}
