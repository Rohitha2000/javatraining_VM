package com.java.Threadrunmethod;
//call the run() method more than one time
	public class RunExp3 extends Thread  
	{    
	    public void run()  
	    {    
	    	System.out.println("thread name---" +Thread.currentThread().getName());
		       
	        for(int i=1;i<3;i++)  
	        {    
	            try  
	            {  
	                Thread.sleep(5000);  
	            }catch(InterruptedException e){System.out.println(e);}
	            System.out.println("thread name---" +Thread.currentThread().getName());
	        System.out.println(i);    
	       
	        }    
	    }    
	    public static void main(String args[])  
	    {    
	        RunExp3 t1=new RunExp3();    
	        RunExp3 t2=new RunExp3();    
//	        t1.run();    
//	        t2.run();    
            t1.start();
            t2.start();
	    
	    }    
	}    


