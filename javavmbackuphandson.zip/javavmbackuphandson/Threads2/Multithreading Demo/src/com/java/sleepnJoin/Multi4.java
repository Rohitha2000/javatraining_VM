package com.java.sleepnJoin;

//What if we call run() method directly instead start() method?

class Multi4 extends Thread{  
	 public void run(){  
	  for(int i=1;i<2;i++){  
		  System.out.println("thread cuurently entered---" +Thread.currentThread().getName());
	    try{
	    	Thread.sleep(50);
	    	 System.out.println("thread inside loop" +Thread.currentThread().getName());
	    	}
	    catch(InterruptedException e)
	    {
	    	System.out.println(e);}  
	    System.out.println("thread i" +Thread.currentThread().getName());
	    System.out.println(i);  
	  }  
	 }  
	 public static void main(String args[]){  
	  Multi4 t1=new Multi4();  
	  Multi4 t2=new Multi4();  
	   t1.setName("t1--thread1");
	   t2.setName("t2--thread2");
	  t1.start(); 
	  t2.start(); 
	 }  
	}  
//As you can see in the above program that there is no context-switching because here t1 and t2 
//will be treated as normal object not thread object.