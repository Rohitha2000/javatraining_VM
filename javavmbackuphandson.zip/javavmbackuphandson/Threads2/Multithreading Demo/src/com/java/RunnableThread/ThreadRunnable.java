package com.java.RunnableThread;

import java.util.Iterator;

class multi implements Runnable
{
	public void run()
	{
	try {
		
		System.out.println("thread id--" +Thread.currentThread().getId () + "-- running");
	}
	catch(Exception e)
	{
		System.out.println(e);
		
	}
	}

}
public class ThreadRunnable {
	
	public static void main(String[] args) {
		
		
		int n=10;
		for (int i = 0; i < n; i++) {
//			multi obj = new multi();
//			Thread tobj = new Thread(obj);
			
			Thread tobj = new Thread(new multi());
			
			tobj.start();
			
		}
		
		
	}

}
