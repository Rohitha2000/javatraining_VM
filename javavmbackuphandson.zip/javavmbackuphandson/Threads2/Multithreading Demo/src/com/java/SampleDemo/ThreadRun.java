package com.java.SampleDemo;

class ThreadRun1 implements Runnable
{
	public void run()
	
	{
		try
		{
		System.out.println("current thread--" +Thread.currentThread().getName());
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
	}
	

}

public class ThreadRun {

	public static void main(String[] args) {
		
		int n=10;
		for (int i = 0; i < n; i++) {
			
//			ThreadRun1 obj = new ThreadRun1();
//			Thread tobj = new Thread(obj);
			
			Thread tobj = new Thread(new ThreadRun1());
			tobj.start();
		
		
		
	}

}
}
