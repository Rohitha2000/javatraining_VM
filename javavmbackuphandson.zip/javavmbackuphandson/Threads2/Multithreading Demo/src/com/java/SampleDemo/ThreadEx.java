package com.java.SampleDemo;

class Threadex1 extends Thread
{
	public void run()
	{
		try
		{
		System.out.println("current thread--" +Thread.currentThread().getName());
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}


}

public class ThreadEx {

	public static void main(String[] args) {
		int n=10;
		for (int i = 0; i < n; i++) {
			
			Threadex1 obj = new Threadex1();
			obj.start();
			
			
		}

	}

}
