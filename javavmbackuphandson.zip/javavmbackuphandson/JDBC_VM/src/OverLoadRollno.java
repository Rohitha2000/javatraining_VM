	





import java.sql.Connection;



import java.sql.DriverManager;

import java.sql.PreparedStatement;

import java.sql.ResultSet;

import java.sql.ResultSetMetaData;

import java.sql.Statement;

import java.util.Scanner;

public class OverLoadRollno {

 Connection con=null;

 OverLoadRollno() throws Exception

 {

 Class.forName("com.mysql.cj.jdbc.Driver");

  con=DriverManager.getConnection("jdbc:mysql://localhost:3306/vm","root","rtha1209");

 }

 void m1()throws Exception

 {

 Statement st=con.createStatement();

 String query="select * from students";

 ResultSet rs=st.executeQuery(query);

 ResultSetMetaData rsmd=rs.getMetaData();

 for(int i=1;i<=rsmd.getColumnCount();i++)

 {

 System.out.print(rsmd.getColumnName(i)+"\t");

 }

 System.out.println();

 while(rs.next())

 {

 System.out.println(rs.getInt(1)+"\t"+rs.getString(2)+"\t"+rs.getString(3)+"\t"+rs.getDate(4)+"\t"+rs.getDouble(5));

 }

 }

 void m2(int roll) throws Exception

 {

 int re= roll;

 //Statement st=con.createStatement();

 System.out.println("before q");

 String query1="select * from students where rollno=?";

 System.out.println("after q");

 PreparedStatement ps=con.prepareStatement(query1);

 System.out.println("after q");

 ps.setInt(1, re);

 System.out.println("re "+re);

 ResultSet rs=ps.executeQuery();

 System.out.println("resul");

 ResultSetMetaData rsmd=rs.getMetaData();

 System.out.println("meta");

 for(int i=1;i<=rsmd.getColumnCount();i++)

 {

 System.out.print(rsmd.getColumnName(i)+"\t");

 }

 System.out.println();

 while(rs.next())

 {

 System.out.println(rs.getInt(1)+"\t"+rs.getString(2)+"\t"+rs.getString(3)+"\t"+rs.getDate(4)+"\t"+rs.getDouble(5));

 }

 }

 public static void main(String[] args) throws Exception {

 // TODO Auto-generated method stub

OverLoadRollno ro= new OverLoadRollno();

ro.m1();

int roll;

Scanner s= new Scanner(System.in);

System.out.println("enter roll");

roll= s.nextInt();

System.out.println("showing table on given comdition "+ roll);

ro.m2(roll);

System.out.println("r1 ");

 }

}
	


