import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.Scanner;

class DAO
{
	Scanner s= new Scanner(System.in);
 void insert(Connection con) throws Exception
 {
	 int rollno;
	 String stname, standard;
	 String dob;
	 double fees;
	 System.out.println("Enter rollno");
	 rollno= s.nextInt();
	 System.out.println("Enter student");
	 stname= s.next();
	 System.out.println("Enter standard");
	 standard= s.next();
	 System.out.println("Enter date of birth");
	 dob= s.next();
	 System.out.println("Enter fee");
	 fees= s.nextDouble();

	 String query="insert into students values(?,?,?,?,?)";
	 PreparedStatement ps=con.prepareStatement(query);
	 ps.setInt(1, rollno);
	 ps.setString(2, stname);
	 ps.setString(3, standard);
	 ps.setString(4, dob);
	 ps.setDouble(5, fees);
	 int i= ps.executeUpdate();
	 if(i>0)
		 System.out.println("row inserted.......");
	  
 }
 void delete(Connection con) throws Exception
 {
	 int roll;
	 System.out.println("Enter roll no to select for deletion");
     roll= s.nextInt();
     String query="delete from students where rollno=?";
     PreparedStatement ps=con.prepareStatement(query);
      ps.setInt(1, roll);
      int i= ps.executeUpdate();
      if(i>0)
      {
    	  System.out.println("row deleted successfully...");
      }
 }
 void update(Connection con) throws Exception 
 {
	 int roll;
	 double fee;
	 System.out.println("Enter rollno to update record");
	 roll= s.nextInt();
	 System.out.println("Enter fee to update");
	 fee= s.nextDouble();
	
     String query="update students set fees=? where rollno=?";
     PreparedStatement ps=con.prepareStatement(query);
      ps.setDouble(1, fee);
      ps.setInt(2, roll);
      int i= ps.executeUpdate();
      if(i>0)
      {
    	  System.out.println("row updated successfully...");
      }
 }
 void display(Connection con) throws Exception
 {
	 int roll;
	 System.out.println("Enter rollno to display record");
	 roll= s.nextInt();
	 String query1="select * from students where rollno=?";
	 PreparedStatement ps=con.prepareStatement(query1);
	 ps.setInt(1, roll);
	 ResultSet rs=ps.executeQuery();
	 ResultSetMetaData rsmd=rs.getMetaData(); 
	 for(int i=1;i<=rsmd.getColumnCount();i++)
	 {
	 System.out.print(rsmd.getColumnName(i)+"\t");
	 }
	 System.out.println();
	 while(rs.next())
	 {
	 System.out.println(rs.getInt(1)+"\t"+rs.getString(2)+"\t"+rs.getString(3)+"\t"+rs.getDate(4)+"\t"+rs.getDouble(5));
	 }
 }
 void displayAll(Connection con) throws Exception
 {
	 Statement st=con.createStatement();
	 String query="select * from students";
	 ResultSet rs=st.executeQuery(query);
	 ResultSetMetaData rsmd=rs.getMetaData();
	 for(int i=1;i<=rsmd.getColumnCount();i++)
	 {
	 System.out.print(rsmd.getColumnName(i)+"\t");
	 }
	 System.out.println();
	 while(rs.next())
	 {
	 System.out.println(rs.getInt(1)+"\t"+rs.getString(2)+"\t"+rs.getString(3)+"\t"+rs.getDate(4)+"\t"+rs.getDouble(5));
	 }
 }
 
 
}
public class CredJdbc {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		 Class.forName("com.mysql.cj.jdbc.Driver");
		
		 Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/vm","root","rtha1209");
        while(true)
        {
        	System.out.println("1. Insert");
        	System.out.println("1. Delete");
        	System.out.println("3. Update");
        	System.out.println("4. Display");
        	System.out.println("5. DisplayAll");
        	System.out.println("6. Exit");
		 System.out.println("enter choice");
        Scanner s= new Scanner(System.in);
        DAO da= new DAO();
        int ch= s.nextInt();
        switch(ch)
        {
             case 1: da.insert(con);
                     break;
             case 2: da.delete(con);        
                     break;
             case 3: da.update(con);       
                     break;
             case 4: da.display(con);
                     break;
             case 5: da.displayAll(con);
                     break;
             case 6: System.exit(0);
                     break;
             default:  System.out.println("please enter correct input");        
                       break;
        }
        
	}

	}

}
