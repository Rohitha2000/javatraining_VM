interface I1 { int a=100; void m1(); }
 class A1 implements I1 {  
	 public void m1()
	 {
			 System.out.println("rhg"); 
} 
 }

public class Main
{
	public static void main(String[] args) {
A1 a= new A1();
a.m1();
	}
}