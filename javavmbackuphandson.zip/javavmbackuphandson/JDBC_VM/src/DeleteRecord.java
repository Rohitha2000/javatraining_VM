import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.SQLSyntaxErrorException;
import java.sql.Statement;
import java.util.Scanner;

public class DeleteRecord {
void dele(int roll) throws SQLSyntaxErrorException, Exception
{
	
	Class.forName("com.mysql.cj.jdbc.Driver");
	 Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/vm","root","rtha1209");


String query="delete from students where rollno=?";
PreparedStatement ps=con.prepareStatement(query);
ps.setInt(1, roll);
int i=	ps.executeUpdate();
if(i>0)
 System.out.println("record deleted successfully ......");
}
	
	void updat(int roll, String nm, String sd) throws Exception
	{
		 String dat;
			Class.forName("com.mysql.cj.jdbc.Driver");
			 Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/vm","root","rtha1209");
				
			 String ldat= "2013-02-09";

		String query2="insert into studentlog values(?,?,?,?)";
		PreparedStatement ps2=con.prepareStatement(query2);
		ps2.setInt(1, roll);
	ps2.setString(2, nm);
	ps2.setString(3, sd);
	ps2.setString(4, ldat);
	int i2= ps2.executeUpdate();
	if(i2>0)
	System.out.println("record inserted successfully ......");
	}
	
	
	
	
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		 
	 int roll= Integer.parseInt(args[0]);
		 
		 String dat;
		Class.forName("com.mysql.cj.jdbc.Driver");
		 Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/vm","root","rtha1209");

		 Statement st=con.createStatement();
		 String query="select stname, standard from students where rollno=1223";
		 ResultSet rs=st.executeQuery(query);
		 System.out.println(" select executed");
		 
//		 for(int i=1;i<=rsmd.getColumnCount();i++)
//		 {
//		 System.out.print(rsmd.getColumnName(i)+"\t");
//		 }
//		 System.out.println();
//		 while(rs.next())
//		 {
//		  System.out.println(rs.getString(1)+"\t"+rs.getString(2)+"\t");
//		 }
	 while(rs.next())
	 {
	     String nm= rs.getString(1);
        String sd= rs.getString(2);
        DeleteRecord d = new DeleteRecord();
    	 d.updat(roll, nm, sd);
    	 d.dele(roll);
	 }
	 
//	 
//	 System.out.println("Enter leave date");
//	 System.out.println(nm+" "+sd+ " "+dat);
////		 
////	
	// DeleteRecord d = new DeleteRecord();
	 
		
////		 
//		 
		 
		 
		 
	}

}
