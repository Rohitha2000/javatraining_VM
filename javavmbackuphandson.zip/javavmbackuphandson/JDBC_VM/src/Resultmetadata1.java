import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;

public class Resultmetadata1 {
 public static void main(String[] args) throws Exception
 {
 Class.forName("com.mysql.cj.jdbc.Driver");
 Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/vm","root","rtha1209");
 Statement st=con.createStatement();
 String query="select *from employeevm";
 ResultSet rs=st.executeQuery(query);
 ResultSetMetaData rsmd=rs.getMetaData();
 for(int i=1;i<=rsmd.getColumnCount();i++)
 {
 System.out.print(rsmd.getColumnName(i)+"\t");
 }
 System.out.println();
 while(rs.next())
 {
  System.out.println(rs.getInt(1)+"\t"+rs.getString(2)+"\t"+rs.getDouble(3));
 }
 st.close();
 con.close();
 }
}