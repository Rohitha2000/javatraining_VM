import java.sql.Connection;



import java.sql.DriverManager;

import java.sql.PreparedStatement;

public class Fit4 { 

 public static void main(String[] args) throws Exception

 {

 Class.forName("com.mysql.cj.jdbc.Driver");

 Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/vm","root","rtha1209");

 String query="update employeevm set ename=? where eno=?";

 PreparedStatement ps=con.prepareStatement(query);

 ps.setString(1, "abcd");

 ps.setInt(2, 55);

 int i=	ps.executeUpdate();

 if(i>0)

 System.out.println("record inserted successfully ......");

 con.close();

 }

}







