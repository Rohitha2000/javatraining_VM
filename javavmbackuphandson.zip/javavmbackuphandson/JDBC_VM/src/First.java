import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.*;

public class First {
 public static void main(String[] args) throws Exception
 {
 Class.forName("com.mysql.cj.jdbc.Driver");
 System.out.println("driver loaded");
 Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/vm","root","rtha1209");
 if(con!=null)
 {
  System.out.println("connection established...."+con);
 }
 Statement st= con.createStatement();
 int i= st.executeUpdate("update employeevm set ename='druva' where eno= 709");
 if(i>0)
	 System.out.println(i+" row inserted");
 
 String query= "select * from employeevm";
 ResultSet rs= st.executeQuery(query);
 while(rs.next())
 {
	 System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getInt(3));
 }
 st.close();
 con.close();
 
 
 
 
}
}