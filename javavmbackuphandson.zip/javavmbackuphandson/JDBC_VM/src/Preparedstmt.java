import java.sql.Connection;

import java.sql.DriverManager;

import java.sql.PreparedStatement;

public class Preparedstmt {

 public static void main(String[] args) throws Exception

 {

 Class.forName("com.mysql.cj.jdbc.Driver");

 Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/vm","root","rtha1209");

 String query="insert into employeevm values(?,?,?)";

 PreparedStatement ps=con.prepareStatement(query);

 ps.setInt(1, 55);

 ps.setString(2, "vamsi");

 ps.setInt(3, 20000);

 int i=	ps.executeUpdate();

 if(i>0)

  System.out.println("record inserted successfully ......");

 con.close();

 }

}
