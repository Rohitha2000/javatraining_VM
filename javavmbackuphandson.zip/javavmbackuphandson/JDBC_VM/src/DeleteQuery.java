import java.sql.Connection;

import java.sql.DriverManager;

import java.sql.PreparedStatement;

public class DeleteQuery{

 public static void main(String[] args) throws Exception

 {

 Class.forName("com.mysql.cj.jdbc.Driver");

 Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/vm","root","rtha1209");

 String query="delete from employeevm where eno=?";

 PreparedStatement ps=con.prepareStatement(query);

  ps.setInt(1, 55);

 int i=	ps.executeUpdate();

 if(i>0)

  System.out.println("record deleted successfully ......");

 con.close();

 }

}





