import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class CommitRollback {
	public static void main(String[] args) throws Exception {
		Statement st;
		Connection con = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/vm", "root", "rtha1209");
			con.setAutoCommit(false);
			st = con.createStatement();
			System.out.println("statement prepared");
			st.addBatch("insert into employeevm values(67,'rajesh',12)");
			st.addBatch("update employeevm set ename='ssss' where eno=22");
			st.addBatch("delete from employeevm where eno=79");
			int res[] = st.executeBatch();
			int sum = 0;
			for (int i = 0; i < res.length; ++i) {
				sum = sum + res[i];
			}
			System.out.println("no.of records that are effected is " + sum);
			boolean flag = true;
			for (int i = 0; i < res.length; ++i) {
				if (res[i] == 0)
					flag = false;
			}
			if (flag)
				con.commit();
			else
				con.rollback();
		} catch (Exception e) {
			e.printStackTrace();
		}
		con.close();
	}
}
