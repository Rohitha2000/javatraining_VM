
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
public class Callablestmt {
	public static void main(String[] args) throws Exception

	{

		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/vm", "root", "rtha1209");
		CallableStatement cs = con.prepareCall("call detail(?)");
		cs.setString(1, "rahul");
		cs.execute();
		ResultSet rs = cs.getResultSet();
		while (rs.next()) {
			System.out.println(rs.getString(1) + " " + rs.getString(2) + " " + rs.getString(3) + " " + rs.getString(4));
		}
		con.close();
	}
}



