import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class ModifyStudentrec {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
			// int roll= s.nextInt();
			 
			 
		 Class.forName("com.mysql.cj.jdbc.Driver");
		 Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/vm","root","rtha1209");
		 String query="update students set fees=? where rollno=?";
		 System.out.println("query q");
		 PreparedStatement ps=con.prepareStatement(query);
		 System.out.println("query ps");
		 int roll= Integer.parseInt(args[0]);
		 System.out.println("query arg");
		 Scanner s= new Scanner(System.in);
		double fee;
		 System.out.println("enter fee");
		 fee= s.nextInt();
		  ps.setDouble(1, fee);
		  ps.setInt(2, roll);
		 int i=	ps.executeUpdate();
		 if(i>0)
			 System.out.println("record updated");

	}

}
