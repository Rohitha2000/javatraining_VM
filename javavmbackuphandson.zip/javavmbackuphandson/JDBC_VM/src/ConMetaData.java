import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
public class ConMetaData {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		 Class.forName("com.mysql.cj.jdbc.Driver");
		 Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/vm","root","rtha1209");
		  DatabaseMetaData dbmd=	con.getMetaData();
		  System.out.println(dbmd.getDatabaseProductName()+"\n "+dbmd.getDatabaseProductVersion());
		  String s1 = dbmd.getURL();
		  String s2 = dbmd.getSQLKeywords();
		  boolean b1 = dbmd.supportsTransactions();
		  boolean b2 = dbmd.supportsSelectForUpdate();
		  System.out.println(s1);
		  System.out.println(s2);
		  System.out.println(b1+" "+b2);
	}

}
