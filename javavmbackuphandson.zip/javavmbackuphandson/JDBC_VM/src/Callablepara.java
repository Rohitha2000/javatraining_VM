import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
public class Callablepara {
	public static void main(String[] args) throws Exception
	{
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/vm", "root", "rtha1209");
		CallableStatement cs = con.prepareCall("call subjects(?,?)");
		cs.setString(1, "history");
		cs.registerOutParameter(2, Types.INTEGER);
		cs.execute();
		System.out.println(cs.getInt(2));
		con.close();
	}
}
