import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class InsertValiddatasql {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		Class.forName("com.mysql.cj.jdbc.Driver");
		 Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/vm","root","rtha1209");
		 String query="insert into students values(?,?,?,?,?)";
		 PreparedStatement ps=con.prepareStatement(query);
		 int rollno;
		 double fees;
		 String stname, standard, dob;
		 java.sql.Date date;
		 Scanner s= new Scanner(System.in);
		 System.out.println("enter roll no");
		 rollno= s.nextInt();
		 System.out.println("enter name");
		 stname= s.next();
		 System.out.println("enter standard");
		 standard= s.next();
		 System.out.println("enter date");
		 dob= s.next();
		  
		 System.out.println("Enter fee");
		 fees= s.nextDouble();
		 char[] che= stname.toCharArray();
		 int chlen= che.length; 
		 int rolen = String.valueOf(rollno).length();
		 if( rolen!= 4)
		 {
			 System.out.println("Rollno not valid"+rolen);
			 System.exit(0);
		 }
		 if(chlen<= 20 )
		 {
		 for(char c: che)
		 {
			 if(Character.isUpperCase(c))
				 System.out.println();
			 else
			 {
				 System.out.println("name is not uppercase");
				 System.exit(0);
			 }
				 
		 }
		 }
		 else
		 {
			 System.out.println("name is above 20 chars");
			 System.exit(0);
		 }
		 
 boolean valid = standard.matches("^M{0,4}(CM|CD|D?C{0,3})(XC|XL|L?X{0,3})(IX|IV|V?I{0,3})$");
 if(valid== true)
	 System.out.println();
 else
 {
	 System.out.println("standard is not in roman ");
	 System.exit(0);
 }

 ps.setInt(1, rollno);
 ps.setString(2, stname);
 ps.setString(3, standard);
 ps.setString(4, dob);
 ps.setDouble(5, fees);
 int i=	ps.executeUpdate();

 if(i>0)

  System.out.println("record inserted successfully ......");

 con.close();
	}

}
